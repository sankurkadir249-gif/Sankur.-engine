# Release Performance Soak — 2026-11-05

A real Release-mode soak was run after fixing a test-only `NDEBUG` issue that caused the SDK unit test to skip prerequisite checks and segfault. The test targets now compile with `-UNDEBUG`, so validation remains active in Release builds.

## Run

- Duration: **921 seconds** (15 minutes 21 seconds)
- Runs: **607**
- Measured frames: **607,000**
- Workload per run: 1,000 frames, 5,000 entities, 30,000 vertices, animation sampling, CPU skinning, deterministic sort/composite, and real Vulkan queue submissions
- Device: `llvmpipe (LLVM 20.1.2, 256 bits)`

## Aggregate metrics

- Minimum FPS across runs: **515.506**
- Average FPS across runs: **727.957**
- Median FPS across runs: **735.866**
- Maximum FPS across runs: **806.854**
- Mean frame time: **1.377 ms**
- Mean p95 frame time: **1.783 ms**
- Mean p99 frame time: **2.172 ms**
- Mean Vulkan queue-submit total per 1,000-frame run: **64.028 ms**

These figures are Release-mode CPU/software-Vulkan benchmark figures. Queue-submit time is wall-clock submission time and is not GPU execution time. No mobile GPU FPS claim is made.

## Validation

- Release SDK CTest: **5/5 passed** before soak.
- The first soak attempt exposed a Release-only test failure; it was fixed before this successful run.
- Raw logs, heartbeat, initial test output, summary and JSON are included under `soak-20261105-fixed/` in the delivered archive.
