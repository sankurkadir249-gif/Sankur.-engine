/*
 * SANKUR ENGINE - mobile rendering configuration facade
 *
 * This file is an original SANKUR-facing API layered over the legacy renderer.
 * The original Irrlicht license and attribution remain in irrlicht.h and doc/.
 */
#ifndef SANKUR_ENGINE_H_INCLUDED
#define SANKUR_ENGINE_H_INCLUDED

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace sankur {

constexpr const char* kEngineName = "SANKUR ENGINE";
constexpr const char* kEngineVersion = "0.1.0-mobile-foundation";

enum class GraphicsQuality : std::uint8_t { Low, Medium, High, Ultra };
enum class ToneMapper : std::uint8_t { None, Reinhard, Aces, AgX };
enum class RenderBackend : std::uint8_t { Auto, OpenGLES3, Vulkan };

struct DeviceCapabilities {
    std::uint32_t maxTextureSize = 2048;
    std::uint32_t maxUniformVectors = 128;
    bool supportsGLES31 = false;
    bool supportsGLES32 = false;
    bool supportsVulkan = false;
    bool supportsAstc = false;
    bool supportsEtc2 = true;
    bool supportsInstancing = false;
};

struct PBRMaterial {
    float baseColor[4] = {1.f, 1.f, 1.f, 1.f};
    float metallic = 0.f;
    float roughness = 0.5f;
    float normalScale = 1.f;
    float occlusionStrength = 1.f;
    float emissive[3] = {0.f, 0.f, 0.f};
    float alphaCutoff = 0.5f;

    void sanitize() noexcept {
        metallic = std::clamp(metallic, 0.f, 1.f);
        roughness = std::clamp(roughness, 0.04f, 1.f);
        normalScale = std::max(0.f, normalScale);
        occlusionStrength = std::clamp(occlusionStrength, 0.f, 1.f);
        alphaCutoff = std::clamp(alphaCutoff, 0.f, 1.f);
    }
};

struct RenderSettings {
    GraphicsQuality quality = GraphicsQuality::Medium;
    RenderBackend backend = RenderBackend::Auto;
    ToneMapper toneMapper = ToneMapper::Aces;
    float exposure = 0.f;
    float renderScale = 1.f;
    bool hdr = true;
    bool imageBasedLighting = true;
    bool cascadedShadows = false;
    bool pcfShadows = true;
    bool ssao = false;
    bool bloom = false;
    bool ssr = false;
    bool gpuInstancing = true;
    std::uint32_t shadowMapSize = 1024;
    std::uint32_t maxDynamicLights = 32;
};

inline RenderSettings settingsFor(GraphicsQuality quality, const DeviceCapabilities& caps) noexcept {
    RenderSettings s;
    s.quality = quality;
    s.quality = quality;
    switch (quality) {
        case GraphicsQuality::Low:
            s.renderScale = 0.70f; s.hdr = false; s.imageBasedLighting = false;
            s.pcfShadows = false; s.shadowMapSize = 512; s.maxDynamicLights = 4;
            break;
        case GraphicsQuality::Medium:
            s.renderScale = 0.85f; s.shadowMapSize = 1024; s.maxDynamicLights = 16;
            s.ssao = false; s.bloom = false;
            break;
        case GraphicsQuality::High:
            s.renderScale = 1.0f; s.shadowMapSize = 2048; s.maxDynamicLights = 32;
            s.ssao = true; s.bloom = true; s.cascadedShadows = true;
            break;
        case GraphicsQuality::Ultra:
            s.renderScale = 1.0f; s.shadowMapSize = 4096; s.maxDynamicLights = 64;
            s.ssao = true; s.bloom = true; s.ssr = true; s.cascadedShadows = true;
            break;
    }
    if (!caps.supportsInstancing) s.gpuInstancing = false;
    if (!caps.supportsGLES31 && !caps.supportsVulkan) s.maxDynamicLights = std::min<std::uint32_t>(s.maxDynamicLights, 8);
    if (caps.maxTextureSize < s.shadowMapSize) s.shadowMapSize = caps.maxTextureSize;
    if (!caps.supportsVulkan && s.ssr) s.ssr = false;
    return s;
}

class AdaptiveResolution {
public:
    explicit AdaptiveResolution(float targetFps = 60.f) : targetFrameMs_(1000.f / targetFps) {}

    float update(float frameMs, float currentScale) noexcept {
        const float error = frameMs - targetFrameMs_;
        // Hysteresis avoids visible resolution oscillation on mobile GPUs.
        if (error > 2.0f) currentScale -= 0.035f;
        else if (error < -2.0f) currentScale += 0.02f;
        return std::clamp(currentScale, minScale_, maxScale_);
    }

    void setRange(float minScale, float maxScale) noexcept {
        minScale_ = std::clamp(minScale, 0.5f, 1.f);
        maxScale_ = std::clamp(maxScale, minScale_, 1.25f);
    }

private:
    float targetFrameMs_;
    float minScale_ = 0.65f;
    float maxScale_ = 1.f;
};

inline float toneMapReinhard(float hdr, float exposure) noexcept {
    const float mapped = hdr * std::pow(2.f, exposure);
    return mapped / (1.f + mapped);
}

inline float toneMapAces(float hdr, float exposure) noexcept {
    const float x = hdr * std::pow(2.f, exposure);
    return std::clamp((x * (2.51f * x + 0.03f)) / (x * (2.43f * x + 0.59f) + 0.14f), 0.f, 1.f);
}

} // namespace sankur

#endif
