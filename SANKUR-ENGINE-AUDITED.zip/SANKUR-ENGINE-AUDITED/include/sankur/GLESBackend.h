#ifndef SANKUR_GLES_BACKEND_H_INCLUDED
#define SANKUR_GLES_BACKEND_H_INCLUDED
#include <cstdint>
#include <string>
namespace sankur::gles {
struct Config { std::uint32_t width = 1, height = 1; bool debug = false; };
class Backend final {
public:
    bool initialize(const Config&, std::string& error);
    void shutdown() noexcept;
    bool available() const noexcept { return initialized_; }
private: bool initialized_ = false;
};
} // namespace sankur::gles
#endif
