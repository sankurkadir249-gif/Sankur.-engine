#ifndef SANKUR_RENDER_GRAPH_H_INCLUDED
#define SANKUR_RENDER_GRAPH_H_INCLUDED

#include <cstdint>
#include <string>
#include <vector>

namespace sankur::render {

enum class ResourceUsage : std::uint8_t { Undefined, ColorAttachment, DepthAttachment, Sampled, Storage, TransferSrc, TransferDst, Present };

struct ResourceDesc {
    std::string name;
    std::uint32_t width = 1;
    std::uint32_t height = 1;
    std::uint32_t format = 0;
    ResourceUsage initialUsage = ResourceUsage::Undefined;
};

struct ResourceHandle { std::uint32_t id = 0; };

struct PassDesc {
    std::string name;
    std::vector<ResourceHandle> reads;
    std::vector<ResourceHandle> writes;
};

class Graph final {
public:
    ResourceHandle createResource(ResourceDesc desc);
    std::uint32_t addPass(PassDesc pass);
    bool compile(std::string& error);
    const std::vector<std::uint32_t>& executionOrder() const noexcept { return order_; }
    const std::vector<ResourceDesc>& resources() const noexcept { return resources_; }
    const std::vector<PassDesc>& passes() const noexcept { return passes_; }
    void reset() noexcept;

private:
    std::vector<ResourceDesc> resources_;
    std::vector<PassDesc> passes_;
    std::vector<std::uint32_t> order_;
};

} // namespace sankur::render

#endif
