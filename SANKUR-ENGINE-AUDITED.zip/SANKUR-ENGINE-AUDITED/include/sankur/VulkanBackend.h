#ifndef SANKUR_VULKAN_BACKEND_H_INCLUDED
#define SANKUR_VULKAN_BACKEND_H_INCLUDED

#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include <vulkan/vulkan.h>

namespace sankur::vulkan {

struct PhysicalDeviceInfo {
    std::string name;
    std::uint32_t apiVersion = 0;
    std::uint32_t vendorId = 0;
    VkPhysicalDeviceType type = VK_PHYSICAL_DEVICE_TYPE_OTHER;
    bool supportsGraphicsQueue = false;
    bool supportsPresent = false;
    bool supportsSwapchain = false;
};

struct VulkanConfig {
    const char* applicationName = "SANKUR ENGINE";
    std::uint32_t applicationVersion = VK_MAKE_VERSION(0, 1, 0);
    bool enableValidation = false;
    bool headless = true;
};
struct BufferDesc {
    VkDeviceSize size = 0;
    VkBufferUsageFlags usage = 0;
    VkMemoryPropertyFlags memory = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
    const void* initialData = nullptr;
};
struct ImageDesc {
    std::uint32_t width = 1;
    std::uint32_t height = 1;
    VkFormat format = VK_FORMAT_R8G8B8A8_UNORM;
    VkImageUsageFlags usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    VkImageTiling tiling = VK_IMAGE_TILING_OPTIMAL;
    VkMemoryPropertyFlags memory = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
};
struct BufferResource { VkBuffer buffer = VK_NULL_HANDLE; VkDeviceMemory memory = VK_NULL_HANDLE; VkDeviceSize size = 0; };
struct ImageResource { VkImage image = VK_NULL_HANDLE; VkDeviceMemory memory = VK_NULL_HANDLE; VkImageView view = VK_NULL_HANDLE; };
struct FrameSync { VkSemaphore imageAvailable = VK_NULL_HANDLE; VkSemaphore renderFinished = VK_NULL_HANDLE; VkFence inFlight = VK_NULL_HANDLE; };

class Backend final {
public:
    Backend() = default;
    ~Backend();
    Backend(const Backend&) = delete;
    Backend& operator=(const Backend&) = delete;

    bool initialize(const VulkanConfig& config, std::string& error);
    void shutdown() noexcept;
    bool isInitialized() const noexcept { return device_ != VK_NULL_HANDLE; }
    VkInstance instance() const noexcept { return instance_; }
    VkPhysicalDevice physicalDevice() const noexcept { return physicalDevice_; }
    VkDevice device() const noexcept { return device_; }
    VkSurfaceKHR surface() const noexcept { return surface_; }
    VkSwapchainKHR swapchain() const noexcept { return swapchain_; }
    VkQueue graphicsQueue() const noexcept { return graphicsQueue_; }
    std::uint32_t graphicsQueueFamily() const noexcept { return graphicsQueueFamily_; }
    const std::vector<PhysicalDeviceInfo>& devices() const noexcept { return devices_; }
    bool submitEmptyCommandBuffer(std::string& error);
    bool createBuffer(const BufferDesc& desc, BufferResource& out, std::string& error);
    bool createImage(const ImageDesc& desc, ImageResource& out, std::string& error);
    void destroyBuffer(BufferResource& resource) noexcept;
    void destroyImage(ImageResource& resource) noexcept;
    bool createFrameSync(FrameSync& out, std::string& error);
    void destroyFrameSync(FrameSync& sync) noexcept;
    bool immediateSubmit(const std::function<void(VkCommandBuffer)>& record, std::string& error);

private:
    bool createInstance(const VulkanConfig& config, std::string& error);
    bool selectPhysicalDevice(const VulkanConfig& config, std::string& error);
    bool createLogicalDevice(std::string& error);
    bool createCommandPool(std::string& error);
    bool createHeadlessSurface(std::string& error);
    bool createSwapchain(std::string& error);
    bool findMemoryType(std::uint32_t typeBits, VkMemoryPropertyFlags properties, std::uint32_t& index) const;
    void destroyLogicalDevice() noexcept;
    void destroyInstance() noexcept;

    VkInstance instance_ = VK_NULL_HANDLE;
    VkSurfaceKHR surface_ = VK_NULL_HANDLE;
    VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice_ = VK_NULL_HANDLE;
    VkDevice device_ = VK_NULL_HANDLE;
    VkQueue graphicsQueue_ = VK_NULL_HANDLE;
    VkCommandPool commandPool_ = VK_NULL_HANDLE;
    std::uint32_t graphicsQueueFamily_ = UINT32_MAX;
    std::vector<PhysicalDeviceInfo> devices_;
    bool validationEnabled_ = false;
};

} // namespace sankur::vulkan

#endif
