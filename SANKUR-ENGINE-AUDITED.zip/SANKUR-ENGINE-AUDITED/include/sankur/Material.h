#ifndef SANKUR_MATERIAL_H_INCLUDED
#define SANKUR_MATERIAL_H_INCLUDED
#include <algorithm>
#include <cstdint>

namespace sankur::material {
struct TextureHandle {
    std::uint64_t id = 0;
    std::uint32_t width = 0, height = 0;
    bool valid() const noexcept { return id != 0; }
};

enum MaterialFeature : std::uint32_t {
    OutputSrgb = 1u << 0,
    EnableIbl = 1u << 1,
    EnableShadows = 1u << 2,
    MobileQuality = 1u << 3
};

struct PBRMaterial {
    float baseColor[4] = {1.f, 1.f, 1.f, 1.f};
    float metallic = 0.f;
    float roughness = 1.f;
    float exposure = 0.f;       // EV100-style stops, applied before tone mapping.
    float iblStrength = 1.f;
    float shadowBias = 0.001f;
    float maxEnvironmentLod = 5.f;
    std::uint32_t features = OutputSrgb;
    TextureHandle baseColorTexture{};
    TextureHandle normalTexture{};
    TextureHandle metallicRoughnessTexture{};
    TextureHandle occlusionTexture{};
    TextureHandle emissiveTexture{};

    void sanitize() noexcept {
        metallic = std::clamp(metallic, 0.f, 1.f);
        roughness = std::clamp(roughness, 0.04f, 1.f);
        exposure = std::clamp(exposure, -16.f, 16.f);
        iblStrength = std::max(iblStrength, 0.f);
        shadowBias = std::clamp(shadowBias, 0.f, 0.1f);
        maxEnvironmentLod = std::clamp(maxEnvironmentLod, 0.f, 32.f);
        for (float& channel : baseColor)
            channel = std::clamp(channel, 0.f, 1.f);
    }
};

struct MaterialBindings {
    const PBRMaterial* material = nullptr;
    std::uint32_t set = 0;
    bool complete() const noexcept { return material != nullptr; }
};
} // namespace sankur::material
#endif
