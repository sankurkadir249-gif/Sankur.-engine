# SANKUR ENGINE Android başlangıç notları

Bu arşivde Android için hazır Gradle/NDK projesi henüz bulunmaz. Mevcut `SankurEngine.h` API'si Android NDK r25+ ve C++17 ile kullanılabilir.

Önerilen ilk entegrasyon:

```cpp
#include <SankurEngine.h>

sankur::DeviceCapabilities caps;
caps.supportsGLES31 = true; // gerçek EGL/GL extension sorgusu ile doldur
caps.supportsInstancing = true;
auto settings = sankur::settingsFor(sankur::GraphicsQuality::High, caps);
```

Gerçek GLES/Vulkan backend'i eklenene kadar bu yapılandırma tek başına GPU render pass'i oluşturmaz. Bu ayrım özellikle korunmuştur; çalışmayan bir backend tamamlanmış gibi sunulmamıştır.
