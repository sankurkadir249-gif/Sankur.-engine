#include <jni.h>
#include <string>
#include <sankur/VulkanBackend.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_sankur_engine_MainActivity_nativeEngineStatus(JNIEnv* env, jclass) {
    sankur::vulkan::Backend backend;
    sankur::vulkan::VulkanConfig config;
    config.headless = false;
    std::string error;
    const bool available = backend.initialize(config, error);
    const std::string status = available ? "SANKUR ENGINE\\nVulkan device initialized" : "SANKUR ENGINE\\nVulkan unavailable: " + error;
    return env->NewStringUTF(status.c_str());
}
