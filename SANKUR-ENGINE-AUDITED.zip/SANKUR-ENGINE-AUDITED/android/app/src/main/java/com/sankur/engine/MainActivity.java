package com.sankur.engine;

import android.app.Activity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    static { System.loadLibrary("sankur_android"); }
    private static native String nativeEngineStatus();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TextView status = new TextView(this);
        status.setText(nativeEngineStatus());
        setContentView(status);
    }
    @Override protected void onPause() { super.onPause(); }
    @Override protected void onResume() { super.onResume(); }
}
