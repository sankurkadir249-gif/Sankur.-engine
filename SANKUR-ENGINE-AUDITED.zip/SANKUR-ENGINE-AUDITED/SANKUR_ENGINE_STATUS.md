# SANKUR ENGINE — Current Build Status

This checkout contains the legacy Irrlicht codebase, a small SANKUR-facing configuration facade, and an additive dependency-free C++17 game SDK. It is not a completed commercial AAA engine.

## Verified in this checkout

The `game-sdk` CMake project provides headers for ECS, lifecycle, input, configuration, asset validation, CPU profiling, strict GLB container validation, typed glTF runtime conversion, explicit external/data-URI resource resolution, sparse accessor decoding, animation sampling, CPU skinning math, GPU resource state/lifetime contracts, and Android GPU/surface/frame-pacing data contracts. Unit tests cover the existing modules plus GLB error handling, typed mesh/node/material/skin/animation materialization, interpolation/normalization, influence normalization, lifecycle transitions, and shader source presence.

The SDK includes GLSL ES 3.1 and Vulkan-compatible PBR shader source assets with metallic-roughness, normal-map TBN, directional lighting, exposure, and tone mapping. These are source contracts and have not been physically compiled or run on a GPU in this checkout.

## Not claimed or not verified here

No Vulkan/GLES renderer, render pass, framebuffer, shader pipeline runtime, Android NDK integration, audio backend, GPU profiler, or physical-device validation was added. The GLB reader validates the binary container and extracts JSON/BIN bytes; the dependency-free parser converts supported glTF JSON arrays into typed runtime data and can resolve buffers only through the caller-supplied `AssetResolver` (or data-URI decoding). The Android API reports capabilities supplied by a platform integration but does not query hardware itself. GPU resource state transitions remain backend-neutral and perform no Vulkan allocation.

## Test command

```bash
cmake -S game-sdk -B game-sdk/build
cmake --build game-sdk/build
ctest --test-dir game-sdk/build --output-on-failure
```

The local result should be reported from the actual CMake/CTest run; this document does not infer success.

Original Irrlicht licensing and attribution files remain unchanged.


## Runtime-chain progress (2026-11-05)

Implemented and host-validated the next runtime layers: `game-sdk/include/sankur/game_sdk/gltf.hpp` exposes typed buffers, buffer views, accessors, meshes/primitives, nodes with parent links, PBR materials, skins, and animation samplers/channels. JSON conversion now materializes all of those arrays, validates cross-array references, and provides checked decoding for common accessor component types with normalized conversion, interleaved strides, and missing-bufferView zero initialization. `gpu_resources.hpp` adds a backend-neutral resource registry and material binding validation without pretending to allocate Vulkan objects. `android_gpu.hpp` carries a native-window pointer and explicit attach/detach lifecycle bridge while remaining dependency-free for host builds.

Boundaries remain intentional: image decoding, Vulkan buffer/image allocation, descriptor sets, swapchain presentation, and physical Android `ANativeWindow` surface creation remain unimplemented. `AssetResolver` is an explicit integration seam, not a filesystem/network implementation. The dedicated `sankur_game_sdk_gltf_runtime` test covers successful graph materialization and malformed required fields/references.

## Runtime backend pass (2026-11-05, verified)

The top-level SANKUR runtime now includes `include/sankur/VulkanBackend.h` resource abstractions backed by real Vulkan `VkBuffer`/`VkImage` creation, memory-type selection, allocation, binding, image-view creation, host-visible initial uploads, explicit destruction, immediate command submission, and reusable image-available/render-finished/fence synchronization objects. `tests/vulkan_resources_smoke.cpp` exercises those paths against the installed Vulkan implementation.

`include/sankur/GLESBackend.h` and `source/Sankur/GLESBackend.cpp` provide an EGL/GLES 3.1 integration contract with an explicit failure when the required headers are unavailable or when native display/window integration has not been supplied. This checkout has the runtime EGL/GLES shared libraries but no EGL/GLES development headers, so no GL calls are compiled and no success is claimed. A window-surface swapchain, render pass/pipeline, present loop, and triangle shader path remain pending a surface/window integration layer; the existing Vulkan path is intentionally headless-safe and does not fabricate presentation.

Top-level validation performed with `cmake -S . -B build-runtime -DSANKUR_BUILD_TESTS=ON -DSANKUR_BUILD_VULKAN=ON && cmake --build build-runtime -j2 && ctest --test-dir build-runtime --output-on-failure`: 4/4 tests passed (`sankur_engine_smoke`, `sankur_render_graph_smoke`, `sankur_vulkan_smoke`, and `sankur_vulkan_resources_smoke`).

## Engineering pass (2026-11-06, verified)
Vulkan robustness was extended without fabricating presentation: `VK_EXT_headless_surface` is probed before being requested, and its absence now falls back to a real non-presenting device/resource context. Device-local initial buffer data is uploaded through a host-visible staging buffer and `vkCmdCopyBuffer`/fenced immediate submission; non-coherent host mappings are flushed. Resource replacement destroys prior handles, frame-sync creation rejects uninitialized use, and the Vulkan resource smoke test covers both upload classes.

SDK safety improvements include invalid-entity ECS rejection, entity-id exhaustion protection, path-component asset traversal validation, and single-consumption Android frame tokens. Validation completed: top-level Debug 4/4 CTest, top-level Release 4/4 CTest, SDK Debug 5/5 CTest, SDK Release 5/5 CTest, SDK AddressSanitizer/UBSan 5/5 CTest, and shader compilation validation via `glslangValidator`.

Remaining blockers are unchanged and explicit: EGL/GLES development headers and a native window/display integration are absent here; no GLES calls or presentation success are claimed. Full swapchain present/render-pass/pipeline integration, image decoding, descriptor management, Android NDK surface creation, and physical-device Android validation remain future integration work.

## Full engineering audit (2026-11-06)
The host-testable contracts received additional real fixes. `AndroidFramePacer` now owns an active-token set, so unknown, repeated, and otherwise non-issued frame completions are rejected; deadline addition saturates instead of wrapping. Asset manifest/cache validation now rejects empty or dot path components and malformed/non-hex SHA-256 values, including unsafe cache insertions. The dependency-free GLTF parser rejects duplicate object keys and malformed/non-finite JSON numbers. Accessor decoding now checks output-size, stride/span, buffer-view declared-length, and sparse-data arithmetic before pointer arithmetic or indexing.

Final clean validation from this source state: top-level Debug 4/4 CTest passed; top-level Release 4/4 passed; SDK Debug 5/5 passed; SDK AddressSanitizer/UndefinedBehaviorSanitizer 5/5 passed; shader-validation CTest passed for Vulkan and GLES source variants; Vulkan backend/resource smoke passed on llvmpipe. Existing generated build directories and root `vert.spv`/`frag.spv` remain workspace artifacts, not release outputs; no packaging/install target or Android APK/NDK build is claimed.

Remaining blockers are exact and unchanged in scope: this host lacks EGL/GLES development headers and a native display/window provider, so the GLES backend intentionally fails initialization rather than fabricating success. Android NDK `ANativeWindow`/JNI integration, physical Android GPU validation, windowed Vulkan swapchain/present/render-pass/pipeline integration, image decoding, descriptor allocation, and a production packaging pipeline still require platform integration work.
