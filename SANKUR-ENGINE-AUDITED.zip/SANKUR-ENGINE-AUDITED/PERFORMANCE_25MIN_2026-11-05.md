# SANKUR 25-Minute Release Soak

The updated Release benchmark ran for 1,521 seconds (25 minutes 21 seconds), completing 1,018 runs and 1,018,000 measured frames. Each run exercised 5,000 entities, 30,000 vertices, animation sampling, CPU skinning, deterministic sort/composite work, and real Vulkan queue submission through the existing backend. The device was llvmpipe software Vulkan; queue submission time is not GPU execution time and no mobile-GPU claim is made.

Aggregate metrics:

{
  "runs": 1018,
  "frames": 1018000,
  "fps_min": 510.689,
  "fps_avg": 738.3350108055009,
  "fps_median": 745.0640000000001,
  "fps_max": 804.918,
  "frame_avg_ms_mean": 1.3572662082514735,
  "frame_p95_ms_mean": 1.7098801571709235,
  "frame_p99_ms_mean": 2.0884361493123773,
  "queue_ms_total_mean": 63.57149410609037
}

The initial Release CTest result is stored in `soak-20261105-25min/initial-tests.log`; raw runs, heartbeats and JSON summary are included in the delivery archive.
