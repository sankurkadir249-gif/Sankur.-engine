#version 310 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp samplerCube;
precision highp sampler2DShadow;

#ifndef PBR_ENABLE_IBL
#define PBR_ENABLE_IBL 1
#endif
#ifndef PBR_ENABLE_SHADOWS
#define PBR_ENABLE_SHADOWS 1
#endif
#ifndef PBR_MOBILE
#define PBR_MOBILE 0
#endif

const float PI = 3.14159265359;
const float MIN_ROUGHNESS = 0.045;
const uint FEATURE_OUTPUT_SRGB = 1u;

layout(location = 0) in vec2 v_uv;
layout(location = 1) in vec3 v_worldPos;
layout(location = 2) in mat3 v_tbn;
#if PBR_ENABLE_SHADOWS
layout(location = 5) in vec4 v_shadowCoord;
#endif
layout(location = 0) out vec4 o_color;

layout(binding = 1) uniform sampler2D u_baseColor;
layout(binding = 2) uniform sampler2D u_metalRough;
layout(binding = 3) uniform sampler2D u_normal;
#if PBR_ENABLE_IBL
layout(binding = 5) uniform samplerCube u_irradiance;
layout(binding = 6) uniform samplerCube u_prefilteredEnv;
layout(binding = 7) uniform sampler2D u_brdfLut;
#endif
#if PBR_ENABLE_SHADOWS
layout(binding = 8) uniform sampler2DShadow u_shadowMap;
#endif

layout(std140, binding = 4) uniform Material {
    vec4 u_baseFactor;
    float u_metallic;
    float u_roughness;
    float u_exposure;
    uint u_features;
    vec3 u_lightDir;
    float u_iblStrength;
    vec3 u_lightColor;
    float u_shadowBias;
    vec3 u_camera;
    float u_maxEnvLod;
};

vec3 acesFilm(vec3 x) {
    x = max(x, vec3(0.0));
    return clamp((x * (2.51 * x + 0.03)) / max(x * (2.43 * x + 0.59) + 0.14, vec3(1e-5)), 0.0, 1.0);
}
vec3 linearToSrgb(vec3 x) {
    x = max(x, vec3(0.0));
    return mix(12.92 * x, 1.055 * pow(x, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), x));
}
float distributionGGX(float NoH, float alpha) {
    float a2 = alpha * alpha;
    float d = NoH * NoH * (a2 - 1.0) + 1.0;
    return a2 / max(PI * d * d, 1e-5);
}
float geometrySchlickGGX(float NoV, float roughness) {
    float k = (roughness + 1.0) * (roughness + 1.0) * 0.125;
    return NoV / max(NoV * (1.0 - k) + k, 1e-5);
}
float geometrySmith(float NoV, float NoL, float roughness) {
    return geometrySchlickGGX(NoV, roughness) * geometrySchlickGGX(NoL, roughness);
}
vec3 fresnelSchlick(float VoH, vec3 f0) {
    return f0 + (1.0 - f0) * pow(clamp(1.0 - VoH, 0.0, 1.0), 5.0);
}

void main() {
    vec4 base = texture(u_baseColor, v_uv) * u_baseFactor;
    vec2 mr = texture(u_metalRough, v_uv).bg;
    float metallic = clamp(mr.x * u_metallic, 0.0, 1.0);
    float roughness = clamp(max(mr.y * u_roughness, MIN_ROUGHNESS), MIN_ROUGHNESS, 1.0);
    vec3 mapNormal = texture(u_normal, v_uv).xyz * 2.0 - 1.0;
    mapNormal.xy *= min(length(mapNormal.xy), 1.0);
    vec3 N = normalize(v_tbn * mapNormal);
    vec3 V = normalize(u_camera - v_worldPos);
    vec3 L = normalize(-u_lightDir);
    vec3 H = normalize(V + L);
    float NoL = max(dot(N, L), 0.0);
    float NoV = max(dot(N, V), 0.0);
    float NoH = max(dot(N, H), 0.0);
    float VoH = max(dot(V, H), 0.0);
    vec3 f0 = mix(vec3(0.04), base.rgb, metallic);
    vec3 F = fresnelSchlick(VoH, f0);
    vec3 diffuse = (1.0 - F) * (1.0 - metallic) * base.rgb / PI;
    float G = geometrySmith(NoV, NoL, roughness);
    float D = distributionGGX(NoH, roughness * roughness);
    vec3 specular = D * G * F / max(4.0 * NoV * NoL, 1e-4);
    float shadow = 1.0;
#if PBR_ENABLE_SHADOWS
    vec3 sc = v_shadowCoord.xyz / max(v_shadowCoord.w, 1e-5);
    if (all(greaterThanEqual(sc.xy, vec2(0.0))) && all(lessThanEqual(sc.xy, vec2(1.0))) && sc.z <= 1.0)
        shadow = texture(u_shadowMap, vec3(sc.xy, sc.z - u_shadowBias));
#endif
    vec3 color = (diffuse + specular) * u_lightColor * NoL * shadow;
#if PBR_ENABLE_IBL
    vec3 R = reflect(-V, N);
    vec3 ambientDiffuse = texture(u_irradiance, N).rgb * diffuse;
#if PBR_MOBILE
    float lod = 0.0;
#else
    float lod = roughness * max(u_maxEnvLod, 0.0);
#endif
    vec3 envSpec = textureLod(u_prefilteredEnv, R, lod).rgb;
    vec2 brdf = texture(u_brdfLut, vec2(NoV, roughness)).rg;
    color += (ambientDiffuse + envSpec * (F * brdf.x + brdf.y)) * max(u_iblStrength, 0.0);
#else
    color += diffuse * 0.02;
#endif
    color *= exp2(clamp(u_exposure, -16.0, 16.0));
    color = acesFilm(color);
    if ((u_features & FEATURE_OUTPUT_SRGB) != 0u)
        color = linearToSrgb(color);
    o_color = vec4(color, base.a);
}
