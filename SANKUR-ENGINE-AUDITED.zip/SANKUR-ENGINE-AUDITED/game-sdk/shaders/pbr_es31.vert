#version 310 es
precision highp float;

#ifndef PBR_ENABLE_SHADOWS
#define PBR_ENABLE_SHADOWS 1
#endif

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec2 a_uv;
layout(location = 3) in vec4 a_tangent;

layout(std140, binding = 0) uniform Frame {
    mat4 u_viewProj;
    mat4 u_model;
    mat4 u_lightViewProj;
};

layout(location = 0) out vec2 v_uv;
layout(location = 1) out vec3 v_worldPos;
layout(location = 2) out mat3 v_tbn;
#if PBR_ENABLE_SHADOWS
layout(location = 5) out vec4 v_shadowCoord;
#endif

void main() {
    mat3 normalMatrix = mat3(u_model);
    vec3 n = normalize(normalMatrix * a_normal);
    vec3 t = normalMatrix * a_tangent.xyz;
    t -= n * dot(n, t);
    float tLen = length(t);
    t = tLen > 1e-5 ? t / tLen : normalize(abs(n.z) < 0.999 ? cross(n, vec3(0.0, 0.0, 1.0)) : cross(n, vec3(0.0, 1.0, 0.0)));
    vec3 b = normalize(cross(n, t)) * (a_tangent.w < 0.0 ? -1.0 : 1.0);
    vec4 world = u_model * vec4(a_position, 1.0);
    v_worldPos = world.xyz;
    v_uv = a_uv;
    v_tbn = mat3(t, b, n);
#if PBR_ENABLE_SHADOWS
    v_shadowCoord = u_lightViewProj * world;
#endif
    gl_Position = u_viewProj * world;
}
