#!/usr/bin/env python3
"""Deterministic starter asset packer for SANKUR game projects."""
import hashlib, json, pathlib, sys

def main(root: str, output: str) -> None:
    base = pathlib.Path(root).resolve()
    files = []
    for path in sorted((base / "assets").rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            files.append({"path": str(path.relative_to(base)), "sha256": digest, "bytes": path.stat().st_size})
    pathlib.Path(output).write_text(json.dumps({"schema": 1, "files": files}, indent=2) + "\n")
    print(f"packed {len(files)} assets -> {output}")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else ".", sys.argv[2] if len(sys.argv) > 2 else "asset-index.json")
