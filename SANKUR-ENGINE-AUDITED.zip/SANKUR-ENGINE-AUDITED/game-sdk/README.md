# SANKUR Game SDK

A dependency-free C++17 gameplay and rendering-foundation layer over the existing `include/SankurEngine.h` facade. It is intentionally a foundation, not a complete renderer or commercial engine.

## Implemented modules

- Existing ECS, lifecycle, input, config, assets, and CPU profiling headers.
- `gltf.hpp`: strict GLB 2 container reader plus dependency-free glTF 2 JSON parsing into typed buffers, buffer views, accessors, meshes/primitives, nodes with derived parent links, PBR materials, skins, and animation samplers/channels. Accessor decoding supports common scalar/vector/matrix component formats, normalized conversion, interleaved strides, zero-filled missing buffer views, and validated sparse overlays; cross-array references are checked during materialization. An explicit `AssetResolver` contract handles external URIs, while base64 and non-base64 data URIs are decoded without filesystem or network assumptions.
- `animation.hpp`: deterministic scalar/vector/quaternion track sampling with STEP and LINEAR modes, normalized quaternion output, clamped endpoints, and safe empty-track behavior.
- `skinning.hpp`: dependency-free Mat4/Vec3 CPU transforms, normalized four-joint influences, invalid-influence handling, and joint-matrix helpers.
- `android_gpu.hpp`: Vulkan/GLES capability-report data, explicit Android surface/context lifecycle transitions, and a dependency-free frame-pacing/in-flight-frame contract. This is a contract, not a fake GPU implementation.
- `shaders/`: GLSL ES 3.1 and Vulkan-compatible GLSL PBR vertex/fragment sources covering energy-conserving metallic-roughness GGX/Smith lighting, guarded ACES fitted tone mapping, exposure and optional sRGB transfer, robust normal-map/tangent fallbacks, optional irradiance/prefiltered-environment/BRDF-LUT IBL, and shadow-coordinate/PCF-ready interfaces. `PBR_ENABLE_IBL`, `PBR_ENABLE_SHADOWS`, and `PBR_MOBILE` are compile-time switches; the mobile validation build disables IBL and shadows and avoids environment LOD work.
- `include/sankur/Material.h`: common PBR material data now carries exposure, IBL strength, shadow bias, environment LOD, and feature bits (`OutputSrgb`, `EnableIbl`, `EnableShadows`, `MobileQuality`) with bounded sanitization.

No external libraries, network downloads, Android SDK, Vulkan loader, GLES runtime, or JSON dependency are required to build the SDK tests. Image/texture decoding and actual GPU upload remain outside this dependency-free layer. `gpu_resources.hpp` now models explicit Created→Uploading→Resident/Failed transitions and rejects stale or non-resident handles; it does not allocate Vulkan/GLES objects. The shader CMake target does perform source compilation with the installed `glslangValidator` for default Vulkan/GLES and mobile feature-off variants, but it does not claim device execution, visual output, real shadow filtering, texture residency, or runtime binding/upload integration. The existing benchmark remains CPU-only when run with `--no-vulkan`.

## Build and test

```bash
cmake -S game-sdk -B game-sdk/build
cmake --build game-sdk/build
ctest --test-dir game-sdk/build --output-on-failure
```

Targets are the header-only `sankur_game_sdk`, startup sample `sankur_game`, unit test executable `sankur_game_sdk_tests`, `sankur_game_sdk_benchmark`, source-only shader target `sankur_game_sdk_shaders`, and validator target `sankur_game_sdk_shader_validate` when `glslangValidator` is installed. The validator covers four Vulkan/GLES source combinations plus mobile feature-off variants; CTest runs it alongside the SDK and benchmark regression tests.

## Performance benchmark

Build and run the short deterministic regression mode:

```bash
cmake -S game-sdk -B game-sdk/build
cmake --build game-sdk/build --target sankur_game_sdk_benchmark
game-sdk/build/sankur_game_sdk_benchmark --deterministic --frames 8 --warmup 1 --no-vulkan
ctest --test-dir game-sdk/build -R sankur_game_sdk_benchmark_regression --output-on-failure
```

The benchmark performs ECS iteration, animation track sampling, CPU skinning, and a deterministic cull/sort/composite render-graph-like pass. It reports iterations, FPS, frame-time min/average/p50/p95/p99/max, process CPU time, a checksum, and the selected backend/device. Use `--frames`, `--warmup`, `--entities`, and `--vertices` to scale the workload.

When Vulkan is found by CMake, the benchmark also compiles the existing backend and attempts real command-buffer submission by default. `Vulkan queue submission time` is wall time around `vkQueueSubmit` plus its fence wait; it is not fabricated GPU execution timing and is explicitly separate from CPU frame time. The `backend` and `device` lines identify the actual driver, including software devices such as llvmpipe. Use `--no-vulkan` for CPU-only comparisons.
