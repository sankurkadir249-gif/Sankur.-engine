#include <SankurEngine.h>
#include <chrono>
#include <iostream>
#include <thread>

int main() {
    sankur::DeviceCapabilities caps;
    caps.supportsGLES31 = true;
    caps.supportsInstancing = true;
    auto settings = sankur::settingsFor(sankur::GraphicsQuality::High, caps);
    sankur::AdaptiveResolution scaler(60.f);

    constexpr double fixedStep = 1.0 / 60.0;
    double accumulator = 0.0;
    auto previous = std::chrono::steady_clock::now();
    for (int frame = 0; frame < 3; ++frame) {
        const auto now = std::chrono::steady_clock::now();
        const double delta = std::chrono::duration<double>(now - previous).count();
        previous = now;
        accumulator += delta;
        while (accumulator >= fixedStep) accumulator -= fixedStep;
        settings.renderScale = scaler.update(static_cast<float>(delta * 1000.0), settings.renderScale);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    std::cout << sankur::kEngineName << " game template ready; renderScale=" << settings.renderScale << '\n';
    return 0;
}
