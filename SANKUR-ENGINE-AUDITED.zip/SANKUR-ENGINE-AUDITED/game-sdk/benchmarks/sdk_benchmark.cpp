#include <sankur/game_sdk/animation.hpp>
#include <sankur/game_sdk/ecs.hpp>
#include <sankur/game_sdk/skinning.hpp>

#ifdef SANKUR_BENCHMARK_HAS_VULKAN
#include "sankur/VulkanBackend.h"
#endif

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <cstdio>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

namespace {
using namespace sankur::sdk;
using Clock = std::chrono::steady_clock;

struct Options {
    std::size_t frames = 120;
    std::size_t warmup = 10;
    std::size_t entities = 2000;
    std::size_t vertices = 12000;
    bool deterministic = false;
    bool vulkan = true;
};

struct Position { float x, y, z; };
struct Velocity { float x, y, z; };
struct RenderItem { float depth, material; };

struct Stats {
    std::vector<double> frameMs;
    double cpuSeconds = 0.0;
    double queueMs = 0.0;
    std::uint64_t checksum = 0;
};

void usage(const char* name) {
    std::cout << "Usage: " << name << " [--frames N] [--warmup N] [--entities N] [--vertices N]"
              << " [--deterministic] [--no-vulkan]\n";
}

bool number(const char* text, std::size_t& value) {
    try {
        const auto parsed = std::stoull(text);
        if (parsed == 0) return false;
        value = static_cast<std::size_t>(parsed);
        return true;
    } catch (...) { return false; }
}

bool parse(int argc, char** argv, Options& o) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") { usage(argv[0]); return false; }
        if (arg == "--deterministic") { o.deterministic = true; continue; }
        if (arg == "--no-vulkan") { o.vulkan = false; continue; }
        if (i + 1 >= argc) { std::cerr << "Missing value for " << arg << '\n'; return false; }
        std::size_t* destination = nullptr;
        if (arg == "--frames") destination = &o.frames;
        else if (arg == "--warmup") destination = &o.warmup;
        else if (arg == "--entities") destination = &o.entities;
        else if (arg == "--vertices") destination = &o.vertices;
        else { std::cerr << "Unknown option: " << arg << '\n'; return false; }
        if (!number(argv[++i], *destination)) { std::cerr << "Invalid value for " << arg << '\n'; return false; }
    }
    if (o.deterministic) o.warmup = std::min(o.warmup, std::size_t{2});
    return true;
}

struct Fixture {
    Registry registry;
    AnimationClip clip;
    KeyframeTrack<Vec3> translation;
    KeyframeTrack<Quat> rotation;
    std::vector<Vec3> positions;
    std::vector<SkinInfluences> influences;
    std::vector<Mat4> joints;
    std::vector<RenderItem> items;
    std::vector<float> animationOutput;
    std::vector<float> graphScratch;

    explicit Fixture(const Options& o) {
        positions.reserve(o.vertices);
        influences.reserve(o.vertices);
        joints.resize(32, Mat4::identity());
        for (std::size_t i = 0; i < joints.size(); ++i) {
            joints[i].m[12] = std::sin(float(i) * 0.13f);
            joints[i].m[13] = std::cos(float(i) * 0.11f);
            joints[i].m[14] = float(i) * 0.002f;
        }
        for (std::size_t i = 0; i < o.vertices; ++i) {
            positions.push_back({float(i % 97) * 0.01f, float(i % 53) * 0.02f, float(i % 29) * 0.03f});
            SkinInfluences in;
            for (int j = 0; j < 4; ++j) { in.joints[j] = static_cast<std::uint16_t>((i + j * 7) % joints.size()); in.weights[j] = 0.1f + float((i + j) % 5); }
            influences.push_back(in);
        }
        items.resize(o.entities);
        for (std::size_t i = 0; i < o.entities; ++i) {
            const Entity e = registry.create();
            registry.emplace<Position>(e, Position{float(i), 0.0f, 0.0f});
            registry.emplace<Velocity>(e, Velocity{0.001f * float(i % 11), 0.02f, 0.0f});
            items[i] = {float(i % 31), float(i % 17)};
        }
        translation = {{0.0f, 0.5f, 1.0f, 1.5f}, {{0, 0, 0}, {1, 2, 0}, {2, 0, 1}, {3, 1, 0}}, Interpolation::Linear};
        rotation = {{0.0f, 1.0f}, {{0, 0, 0, 1}, {0, 0.4f, 0, 0.9165f}}, Interpolation::Linear};
        clip.name = "benchmark"; clip.duration = 1.5f; clip.channels.push_back({0, AnimationChannel::Path::Translation});
        animationOutput.resize(o.entities);
        graphScratch.resize(o.entities);
    }
};

void runFrame(Fixture& f, std::size_t frame, Stats& stats, bool submitVulkan
#ifdef SANKUR_BENCHMARK_HAS_VULKAN
               , sankur::vulkan::Backend* backend
#endif
) {
    const auto start = Clock::now();
    const float t = float(frame % 150) * (1.0f / 100.0f);
    std::uint64_t checksum = 0;
    f.registry.each<Position, Velocity>([&](Entity, Position& p, Velocity& v) {
        p.x += v.x; p.y += v.y;
        checksum += static_cast<std::uint64_t>(std::fabs(p.x) * 100.0f);
    });
    const Vec3 animated = sample(f.translation, std::fmod(t, 1.5f));
    const Quat orientation = sample(f.rotation, std::fmod(t, 1.0f));
    for (std::size_t i = 0; i < f.animationOutput.size(); ++i)
        f.animationOutput[i] = animated.x + animated.y * 0.5f + orientation.w * 0.25f + float(i % 13) * 0.0001f;
    for (std::size_t i = 0; i < f.positions.size(); ++i) {
        const Vec3 skinned = skinPoint(f.positions[i], f.influences[i], f.joints);
        checksum += static_cast<std::uint64_t>(std::fabs(skinned.x + skinned.y + skinned.z) * 1000.0f);
    }
    // A small deterministic pass dependency chain models cull -> sort -> composite work.
    for (std::size_t i = 0; i < f.items.size(); ++i) f.graphScratch[i] = f.items[i].depth + f.animationOutput[i] * 0.001f;
    std::stable_sort(f.graphScratch.begin(), f.graphScratch.end());
    for (std::size_t i = 1; i < f.graphScratch.size(); ++i) f.graphScratch[i] += f.graphScratch[i - 1] * 0.0001f;
    checksum += static_cast<std::uint64_t>(f.graphScratch.empty() ? 0.0f : f.graphScratch.back() * 1000.0f);

#ifdef SANKUR_BENCHMARK_HAS_VULKAN
    if (submitVulkan && backend) {
        std::string error;
        const auto queueStart = Clock::now();
        if (!backend->submitEmptyCommandBuffer(error)) {
            std::cerr << "Vulkan queue submission failed: " << error << '\n';
            std::exit(3);
        }
        stats.queueMs += std::chrono::duration<double, std::milli>(Clock::now() - queueStart).count();
    }
#else
    (void)submitVulkan;
#endif
    stats.frameMs.push_back(std::chrono::duration<double, std::milli>(Clock::now() - start).count());
    stats.checksum ^= checksum + static_cast<std::uint64_t>(frame);
}

double percentile(std::vector<double> values, double p) {
    if (values.empty()) return 0.0;
    std::sort(values.begin(), values.end());
    const double index = p * double(values.size() - 1);
    const auto lo = static_cast<std::size_t>(index);
    const auto hi = std::min(lo + 1, values.size() - 1);
    return values[lo] + (values[hi] - values[lo]) * (index - double(lo));
}

} // namespace

int main(int argc, char** argv) {
    Options options;
    if (!parse(argc, argv, options)) return argc > 1 && std::string(argv[1]) == "--help" ? 0 : 2;
    Fixture fixture(options);
    Stats stats;
#ifdef SANKUR_BENCHMARK_HAS_VULKAN
    sankur::vulkan::Backend backend;
    bool vulkanActive = false;
    std::string vulkanError;
    if (options.vulkan) {
        sankur::vulkan::VulkanConfig config;
        config.headless = false; // The benchmark submits commands only; no fake swapchain/GPU frame timing.
        vulkanActive = backend.initialize(config, vulkanError);
    }
#else
    const bool vulkanActive = false;
#endif
    for (std::size_t i = 0; i < options.warmup; ++i) {
#ifdef SANKUR_BENCHMARK_HAS_VULKAN
        runFrame(fixture, i, stats, vulkanActive, vulkanActive ? &backend : nullptr);
#else
        runFrame(fixture, i, stats, false);
#endif
        stats.frameMs.pop_back();
    }
    stats.queueMs = 0.0;
    const std::clock_t cpuStart = std::clock();
    for (std::size_t i = 0; i < options.frames; ++i) {
#ifdef SANKUR_BENCHMARK_HAS_VULKAN
        runFrame(fixture, i + options.warmup, stats, vulkanActive, vulkanActive ? &backend : nullptr);
#else
        runFrame(fixture, i + options.warmup, stats, false);
#endif
    }
    stats.cpuSeconds = double(std::clock() - cpuStart) / double(CLOCKS_PER_SEC);
#ifdef SANKUR_BENCHMARK_HAS_VULKAN
    std::string backendLabel = vulkanActive ? "Vulkan queue submission" : "CPU-only (Vulkan unavailable)";
    std::string deviceLabel = vulkanActive ? backend.devices().front().name : (vulkanError.empty() ? "none" : vulkanError);
    if (vulkanActive) backend.shutdown();
#else
    const std::string backendLabel = "CPU-only (Vulkan target not built)";
    const std::string deviceLabel = "none";
#endif
    const double avg = std::accumulate(stats.frameMs.begin(), stats.frameMs.end(), 0.0) / double(stats.frameMs.size());
    const double totalSeconds = std::accumulate(stats.frameMs.begin(), stats.frameMs.end(), 0.0) / 1000.0;
    const auto minmax = std::minmax_element(stats.frameMs.begin(), stats.frameMs.end());
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "SANKUR SDK benchmark (" << (options.deterministic ? "deterministic" : "throughput") << ")\n"
              << "backend: " << backendLabel << "\ndevice: " << deviceLabel << "\n"
              << "iterations: " << options.frames << " entities: " << options.entities << " vertices: " << options.vertices << '\n'
              << "FPS: " << (totalSeconds > 0.0 ? double(options.frames) / totalSeconds : 0.0) << '\n'
              << "frame time ms: min=" << *minmax.first << " avg=" << avg
              << " p50=" << percentile(stats.frameMs, 0.50) << " p95=" << percentile(stats.frameMs, 0.95)
              << " p99=" << percentile(stats.frameMs, 0.99) << " max=" << *minmax.second << '\n'
              << "CPU time: total=" << stats.cpuSeconds * 1000.0 << " ms avg=" << stats.cpuSeconds * 1000.0 / double(options.frames) << " ms/frame\n"
              << "Vulkan queue submission time: " << stats.queueMs << " ms total, "
              << (vulkanActive ? "measured" : "not measured") << " (not GPU execution time)\n"
              << "checksum: " << stats.checksum << '\n';
    return stats.checksum == 0 && options.frames > 0 ? 4 : 0;
}
