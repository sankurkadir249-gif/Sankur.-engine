#include <sankur/game_sdk/gltf.hpp>
#include <cassert>
#include <cmath>
#include <map>
struct TestResolver : sankur::sdk::AssetResolver { std::map<std::string,std::vector<std::uint8_t>> files; bool resolve(const std::string& u,std::vector<std::uint8_t>& b,std::string& e) override { auto i=files.find(u); if(i==files.end()){e="missing";return false;} b=i->second; return true; } };

using namespace sankur::sdk;

int main() {
    const std::string json = R"json({
      "asset":{"version":"2.0"},
      "buffers":[{"byteLength":12}],
      "bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":12,"target":34962}],
      "accessors":[{"bufferView":0,"componentType":5126,"type":"VEC3","count":1}],
      "materials":[{"name":"paint","pbrMetallicRoughness":{"baseColorFactor":[0.1,0.2,0.3,0.4],"metallicFactor":0.25,"roughnessFactor":0.75}}],
      "meshes":[{"name":"triangle","primitives":[{"attributes":{"POSITION":0},"indices":0,"material":0}]}],
      "nodes":[{"name":"root","children":[1]},{"name":"skinned","mesh":0,"skin":0}],
      "skins":[{"name":"rig","skeleton":0,"joints":[0,1],"inverseBindMatrices":0}],
      "animations":[{"name":"idle","samplers":[{"input":0,"output":0,"interpolation":"STEP"}],"channels":[{"sampler":0,"target":{"node":1,"path":"rotation"}}]}]
    })json";
    GltfJson root;
    GlbError error;
    assert(validateGltfJson(json, &root, &error));
    GltfDocument doc;
    assert(parseTypedGltf(root, std::vector<std::uint8_t>(12), doc, &error));
    assert(doc.buffers.size()==1 && doc.buffers[0].data.size()==12);
    assert(doc.bufferViews.size()==1 && doc.bufferViews[0].target==34962);
    assert(doc.accessors.size()==1 && doc.accessors[0].kind==GltfAccessorKind::Vec3);
    assert(doc.meshes.size()==1 && doc.meshes[0].name=="triangle");
    assert(doc.meshes[0].primitives.size()==1);
    assert(doc.meshes[0].primitives[0].attributes.at("POSITION")==0);
    assert(doc.meshes[0].primitives[0].indices==0 && doc.meshes[0].primitives[0].material==0);
    assert(doc.nodes.size()==2 && doc.nodes[1].parent==0 && doc.nodes[1].mesh==0 && doc.nodes[1].skin==0);
    assert(doc.materials.size()==1 && doc.materials[0].name=="paint");
    assert(std::abs(doc.materials[0].baseColor[2]-0.3f)<1e-6f);
    assert(std::abs(doc.materials[0].metallic-0.25f)<1e-6f && std::abs(doc.materials[0].roughness-0.75f)<1e-6f);
    assert(doc.skins.size()==1 && doc.skins[0].joints.size()==2 && doc.skins[0].inverseBindMatrices==0);
    assert(doc.animations.size()==1 && doc.animations[0].samplers[0].interpolation=="STEP");
    assert(doc.animations[0].channels[0].node==1 && doc.animations[0].channels[0].path=="rotation");

    GltfJson bad;
    assert(validateGltfJson(R"({"asset":{"version":"2.0"},"meshes":[{}]})", &bad));
    assert(!parseTypedGltf(bad, {}, doc, &error));
    assert(error.message=="mesh.primitives must be array");
    assert(validateGltfJson(R"({"asset":{"version":"2.0"},"nodes":[{"children":[4]}]})", &bad));
    assert(!parseTypedGltf(bad, {}, doc, &error));
    assert(error.message=="node child index out of range");
    TestResolver resolver; resolver.files["mesh.bin"]={1,2,3,4};
    GltfJson ext; assert(validateGltfJson(R"({"asset":{"version":"2.0"},"buffers":[{"uri":"mesh.bin","byteLength":4}]})",&ext)); GltfDocument loaded; assert(resolveGltfResources(ext,{},resolver,loaded,&error)); assert(loaded.buffers[0].data.size()==4);
    GltfJson data; assert(validateGltfJson(R"({"asset":{"version":"2.0"},"buffers":[{"uri":"data:application/octet-stream;base64,AQIDBA==","byteLength":4}]})",&data)); assert(resolveGltfResources(data,{},resolver,loaded,&error)); assert(loaded.buffers[0].data[2]==3);
    const std::string sparse=R"({"asset":{"version":"2.0"},"buffers":[{"byteLength":6}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":2},{"buffer":0,"byteOffset":2,"byteLength":4}],"accessors":[{"componentType":5121,"type":"SCALAR","count":4,"sparse":{"count":2,"indices":{"bufferView":0,"componentType":5121},"values":{"bufferView":1}}}]})"; GltfJson sr; assert(validateGltfJson(sparse,&sr)); GltfDocument sd; assert(parseTypedGltf(sr,{1,0,9,8,7,6},sd,&error)); std::vector<float> sv; assert(decodeAccessor(sd,0,sv,&error)); assert(sv.size()==4 && sv[0]==8 && sv[1]==9 && sv[2]==0 && sv[3]==0);
    return 0;
}
