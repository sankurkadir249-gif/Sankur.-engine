#include <sankur/game_sdk/assets.hpp>
#include <sankur/game_sdk/config.hpp>
#include <sankur/game_sdk/ecs.hpp>
#include <sankur/game_sdk/input.hpp>
#include <sankur/game_sdk/lifecycle.hpp>
#include <sankur/game_sdk/profiler.hpp>
#include <sankur/game_sdk/gltf.hpp>
#include <sankur/game_sdk/animation.hpp>
#include <sankur/game_sdk/skinning.hpp>
#include <sankur/game_sdk/android_gpu.hpp>
#include <sankur/game_sdk/gpu_resources.hpp>
#include <sankur/Material.h>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <string>
#include <thread>
using namespace sankur::sdk;
static void put32(std::vector<std::uint8_t>& b,std::uint32_t x){for(int i=0;i<4;++i)b.push_back(std::uint8_t(x>>(8*i)));}
static std::vector<std::uint8_t> glb(){std::vector<std::uint8_t>b;put32(b,0x46546c67);put32(b,2);put32(b,24);put32(b,4);put32(b,0x4e4f534a);b.insert(b.end(),{'{','}',' ',' '});return b;}
int main(){
 Registry r;auto a=r.create(),b=r.create();struct Pos{int x;};struct Vel{int x;};r.emplace<Pos>(a,Pos{1});r.emplace<Vel>(a,Vel{2});r.emplace<Pos>(b,Pos{4});int sum=0;r.each<Pos,Vel>([&](Entity,Pos&p,Vel&v){sum+=p.x+v.x;});assert(sum==3);r.destroy(a);assert(!r.valid(a));
 struct Game:GameLifecycle{int fixed=0,frames=0;void onFixedUpdate(double)override{++fixed;}void onUpdate(double)override{++frames;}}g;FixedTimestepLoop loop;assert(loop.advance(.1,g)==6&&g.frames==1);InputSnapshot in;in.beginFrame();in.set(Key::Action,true);assert(in.pressed(Key::Action));in.beginFrame();assert(!in.pressed(Key::Action));GameConfig bad;bad.width=1;assert(!isValid(bad));
 AssetManifest m;m.project="x";m.assetRoots={"assets"};AssetCacheIndex idx;assert(idx.add({"a.bin",std::string(64,'a'),2}));assert(validateManifest(m,{{"a.bin",std::string(64,'a'),2}}).empty());Profiler::instance().clear();{ScopedCpuProfile p("test");std::this_thread::sleep_for(std::chrono::milliseconds(1));}assert(Profiler::instance().events().size()==1);assert(Profiler::instance().writeChromeTrace("sdk-test-trace.json"));std::remove("sdk-test-trace.json");
 GltfJson doc; assert(validateGltfJson("{\"asset\":{\"version\":\"2.0\"},\"nodes\":[]}",&doc)); assert(!validateGltfJson("{\"asset\":{\"version\":\"1.0\"}}")); assert(!validateGltfJson("{\"asset\":{\"version\":\"2.0\"},\"nodes\":{}}")); assert(!validateGltfJson("{\"asset\":{\"version\":\"2.0\",\"version\":\"2.0\"}}")); assert(!validateGltfJson("{\"asset\":{\"version\":\"2.0\"},\"extras\":1e}",&doc)); AnimationClip clip; clip.channels.push_back({2,AnimationChannel::Path::Rotation}); SkinBinding binding; binding.joints={0,1}; auto bytes=glb();GlbDocument d;GlbError e;assert(GlbReader::read(bytes,d,&e));assert(d.json=="{}");auto badGlb=bytes;badGlb[8]=31;assert(!GlbReader::read(badGlb,d,&e));
 KeyframeTrack<float> ft{{0,1},{2,4},Interpolation::Linear};assert(sample(ft,.5f)==3);ft.interpolation=Interpolation::Step;assert(sample(ft,.5f)==2);KeyframeTrack<Quat> qt{{0,1},{{0,0,0,2},{0,0,0,1}},Interpolation::Linear};assert(std::abs(dot(sample(qt,.5f),sample(qt,.5f))-1)<1e-5f);
 Mat4 id=Mat4::identity();SkinInfluences si;si.joints={0,0,0,0};si.weights={2,0,0,0};assert(std::abs(skinPoint({1,2,3},si,{id}).x-1)<1e-5f);AndroidGpuLifecycle life;assert(life.context()==ContextState::Uninitialized);life.onSurfaceCreated();assert(life.surface()==SurfaceState::Available);life.markContextReady();assert(life.context()==ContextState::Ready);life.onSurfaceDestroyed();assert(life.context()==ContextState::ContextLost);
 GltfJson typed; assert(validateGltfJson("{\"asset\":{\"version\":\"2.0\"},\"buffers\":[{\"byteLength\":8}],\"bufferViews\":[{\"buffer\":0,\"byteLength\":8,\"byteStride\":4}],\"accessors\":[{\"bufferView\":0,\"componentType\":5121,\"type\":\"VEC3\",\"count\":2,\"normalized\":true}]}",&typed)); GltfDocument td; std::vector<std::uint8_t> raw={0,127,255,255,255,0,0,255}; assert(parseTypedGltf(typed,raw,td)); std::vector<float> decoded; assert(decodeAccessor(td,0,decoded)); assert(decoded.size()==6 && std::abs(decoded[0])<1e-6f && std::abs(decoded[1]-.498f)<.01f && decoded[2]==1.f && decoded[3]==1.f); GltfDocument badDoc=td; badDoc.bufferViews[0].byteStride=1; assert(!decodeAccessor(badDoc,0,decoded)); GpuResourceRegistry registry; auto tex=registry.create({GpuResourceKind::Texture,0,4,4,"albedo"}); Material mat; assert(registry.beginUpload(tex)); assert(registry.completeUpload(tex)); mat.bindings.push_back({MaterialSlot::BaseColor,tex,0}); std::string bindError; assert(MaterialBinder{}.bind(mat,registry,bindError)); mat.bindings[0].texture.id=999; assert(!MaterialBinder{}.bind(mat,registry,bindError)); life.attachNativeWindow(reinterpret_cast<void*>(0x1)); assert(life.nativeWindow()!=nullptr); life.detachNativeWindow(); assert(life.nativeWindow()==nullptr); AndroidFramePacer pacer({1,100}); auto f=pacer.begin(10); assert(f && f.deadlineNs==110 && !pacer.begin(20)); assert(pacer.end(f)); sankur::material::PBRMaterial pbr; pbr.metallic=2.f; pbr.roughness=0.f; pbr.exposure=100.f; pbr.iblStrength=-1.f; pbr.features |= sankur::material::EnableIbl; pbr.sanitize(); assert(pbr.metallic==1.f && pbr.roughness>=.04f && pbr.exposure==16.f && pbr.iblStrength==0.f && (pbr.features & sankur::material::EnableIbl)); for(const char* p:{"../shaders/pbr_es31.vert","../shaders/pbr_es31.frag","../shaders/pbr_vk.vert","../shaders/pbr_vk.frag"}){std::ifstream f(p);assert(f.good());std::string s((std::istreambuf_iterator<char>(f)),{});assert(s.find("#version")!=std::string::npos);if(std::string(p).find("frag")!=std::string::npos)assert(s.find("u_light")!=std::string::npos);}
 assert(!validateManifest(m,{{"../escape",std::string(64,'a'),2}}).empty());
 assert(!validateManifest(m,{{"ok.bin",std::string(63,'a')+"!",2}}).empty());
 assert(!idx.add({"../escape",std::string(64,'a'),1}));
 AndroidFramePacer tokens({2,100}); auto f1=tokens.begin(0); auto f2=tokens.begin(0); assert(f1&&f2&&tokens.inFlight()==2); assert(!tokens.end(FrameToken{999,0})); assert(tokens.end(f2)); assert(tokens.end(f1)); assert(tokens.inFlight()==0); assert(!tokens.end(f1));
 return 0;}
