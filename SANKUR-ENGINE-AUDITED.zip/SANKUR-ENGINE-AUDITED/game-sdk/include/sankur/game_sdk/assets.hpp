#pragma once
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
namespace sankur::sdk {
struct AssetRecord { std::string path,sha256; std::uint64_t bytes=0; };
struct AssetManifest { int schema=1; std::string project; std::vector<std::string> assetRoots; std::uint32_t maxTextureDimension=4096; };
inline bool isSafeAssetPath(const std::string& p) {
 if(p.empty()||p[0]=='/'||p.find('\\')!=std::string::npos||p.find(':')!=std::string::npos)return false;
 std::size_t start=0;
 while(start<=p.size()) { const auto end=p.find('/',start); const auto n=end==std::string::npos?p.size():end; const auto part=p.substr(start,n-start); if(part.empty()||part=="."||part=="..")return false; if(end==std::string::npos)break; start=end+1; }
 return true;
}
inline bool isSha256(const std::string& s) {
 if(s.size()!=64)return false;
 for(unsigned char c:s)if(!std::isxdigit(c))return false;
 return true;
}
inline std::vector<std::string> validateManifest(const AssetManifest& m,const std::vector<AssetRecord>& files){
 std::vector<std::string> e;
 if(m.schema!=1)e.push_back("schema must be 1"); if(m.project.empty())e.push_back("project must not be empty"); if(m.assetRoots.empty())e.push_back("assetRoots must not be empty"); if(m.maxTextureDimension==0)e.push_back("maxTextureDimension must be positive");
 for(const auto& root:m.assetRoots)if(!isSafeAssetPath(root))e.push_back("invalid asset root: "+root);
 for(const auto& f:files){if(!isSafeAssetPath(f.path))e.push_back("invalid asset path: "+f.path);if(!isSha256(f.sha256))e.push_back("invalid sha256 for: "+f.path);}
 return e;
}
class AssetCacheIndex {
public:
 bool add(AssetRecord r){if(!isSafeAssetPath(r.path)||!isSha256(r.sha256))return false;entries_[r.path]=std::move(r);return true;}
 const AssetRecord* find(const std::string& p)const{auto i=entries_.find(p);return i==entries_.end()?nullptr:&i->second;}
 std::vector<std::string> paths()const{std::vector<std::string> out;for(auto&x:entries_)out.push_back(x.first);std::sort(out.begin(),out.end());return out;}
 std::size_t size()const{return entries_.size();}
private: std::unordered_map<std::string,AssetRecord> entries_;
};
}
