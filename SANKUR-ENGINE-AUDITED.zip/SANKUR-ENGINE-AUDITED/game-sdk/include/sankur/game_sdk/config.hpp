#pragma once
#include <cmath>
#include <string>
#include <vector>
namespace sankur::sdk {
struct GameConfig { int width=1280,height=720,targetFps=60; float masterVolume=1.f,mouseSensitivity=1.f,gamepadDeadzone=.12f; bool vsync=true,fullscreen=false,dynamicResolution=true; };
struct ValidationIssue { std::string field,message; };
inline std::vector<ValidationIssue> validate(const GameConfig& c){std::vector<ValidationIssue> e; auto add=[&](const char*f,const char*m){e.push_back({f,m});}; if(c.width<320||c.width>16384)add("width","must be between 320 and 16384"); if(c.height<200||c.height>16384)add("height","must be between 200 and 16384"); if(c.targetFps<1||c.targetFps>1000)add("targetFps","must be between 1 and 1000"); if(!std::isfinite(c.masterVolume)||c.masterVolume<0||c.masterVolume>1)add("masterVolume","must be finite and between 0 and 1"); if(!std::isfinite(c.mouseSensitivity)||c.mouseSensitivity<0)add("mouseSensitivity","must be finite and non-negative"); if(!std::isfinite(c.gamepadDeadzone)||c.gamepadDeadzone<0||c.gamepadDeadzone>=1)add("gamepadDeadzone","must be finite and in [0,1)"); return e;}
inline bool isValid(const GameConfig& c){return validate(c).empty();}
}
