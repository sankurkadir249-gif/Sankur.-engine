#pragma once
#include <chrono>
#include <fstream>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
namespace sankur::sdk {
struct ProfileEvent { std::string name,category; std::uint64_t startUs,durationUs; std::uint32_t threadId=0; };
class Profiler { public: static Profiler& instance(){static Profiler p;return p;} void clear(){std::lock_guard<std::mutex>l(m_);events_.clear();} void record(std::string n,std::string c,std::uint64_t s,std::uint64_t d){std::lock_guard<std::mutex>l(m_);events_.push_back({std::move(n),std::move(c),s,d,0});} std::vector<ProfileEvent> events()const{std::lock_guard<std::mutex>l(m_);return events_;} bool writeChromeTrace(const std::string& path)const{std::ofstream out(path);if(!out)return false;out<<"{\"traceEvents\":[";auto e=events();for(size_t i=0;i<e.size();++i){if(i)out<<',';out<<"{\"name\":\""<<escape(e[i].name)<<"\",\"cat\":\""<<escape(e[i].category)<<"\",\"ph\":\"X\",\"ts\":"<<e[i].startUs<<",\"dur\":"<<e[i].durationUs<<",\"pid\":1,\"tid\":"<<e[i].threadId<<"}";}out<<"]}\n";return true;} private: static std::string escape(const std::string&s){std::string o;for(char c:s){if(c=='\\'||c=='\"')o+='\\';o+=c;}return o;} mutable std::mutex m_;std::vector<ProfileEvent>events_;};
class ScopedCpuProfile { public: explicit ScopedCpuProfile(std::string n,std::string c="cpu"):name_(std::move(n)),category_(std::move(c)),start_(clock::now()){} ~ScopedCpuProfile(){auto end=clock::now();auto s=std::chrono::duration_cast<std::chrono::microseconds>(start_.time_since_epoch()).count();auto d=std::chrono::duration_cast<std::chrono::microseconds>(end-start_).count();Profiler::instance().record(name_,category_,static_cast<std::uint64_t>(s),static_cast<std::uint64_t>(d));} private:using clock=std::chrono::steady_clock;std::string name_,category_;clock::time_point start_;};
}
