#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include <memory>
#include <fstream>

namespace sankur::sdk {
struct GlbChunk { std::uint32_t type=0; std::size_t offset=0,length=0; };
struct GlbDocument { std::string json; std::vector<std::uint8_t> bin; std::vector<GlbChunk> chunks; };
struct GlbError { std::string message; std::size_t offset=0; };
struct GltfJson {
    enum class Type { Null, Bool, Number, String, Array, Object };
    Type type=Type::Null; double number=0; bool boolean=false; std::string string;
    std::vector<GltfJson> array; std::map<std::string,GltfJson> object;
    const GltfJson* find(const char* k) const { auto i=object.find(k); return i==object.end()?nullptr:&i->second; }
};
class GltfJsonParser {
    const std::string& s; GlbError* e; std::size_t p=0;
    bool bad(const char* m){if(e)*e={m,p};return false;}
    void ws(){while(p<s.size()&&(s[p]==' '||s[p]=='\t'||s[p]=='\r'||s[p]=='\n'))++p;}
    bool str(std::string& o){
        if(p>=s.size()||s[p++]!='"')return bad("expected JSON string");
        while(p<s.size()){char c=s[p++];if(c=='"')return true;if(c=='\\'){if(p>=s.size())return bad("truncated escape");char q=s[p++];if(std::string("\\\"/bfnrt").find(q)==std::string::npos)return bad("unsupported escape");o+=q=='n'?'\n':q=='r'?'\r':q=='t'?'\t':q=='b'?'\b':q=='f'?'\f':q;}else if((unsigned char)c<32)return bad("control character");else o+=c;}return bad("unterminated string");
    }
    bool val(GltfJson& o){
        ws();if(p>=s.size())return bad("unexpected end");char c=s[p];
        if(c=='{')return obj(o);if(c=='[')return arr(o);if(c=='"'){o.type=GltfJson::Type::String;return str(o.string);}
        if(c=='t'&&s.compare(p,4,"true")==0){p+=4;o.type=GltfJson::Type::Bool;o.boolean=true;return true;}
        if(c=='f'&&s.compare(p,5,"false")==0){p+=5;o.type=GltfJson::Type::Bool;o.boolean=false;return true;}
        if(c=='n'&&s.compare(p,4,"null")==0){p+=4;o.type=GltfJson::Type::Null;return true;}
        if(c=='-'||(c>='0'&&c<='9')){auto b=p;while(p<s.size()&&std::string("-+eE.0123456789").find(s[p])!=std::string::npos)++p;std::size_t used=0;try{o.number=std::stod(s.substr(b,p-b),&used);}catch(...){return bad("invalid number");}if(used!=p-b||!std::isfinite(o.number))return bad("invalid number");o.type=GltfJson::Type::Number;return true;}return bad("invalid value");
    }
    bool obj(GltfJson& o){o.type=GltfJson::Type::Object;++p;ws();if(p<s.size()&&s[p]=='}'){++p;return true;}for(;;){ws();std::string k;if(!str(k))return false;ws();if(p>=s.size()||s[p++]!=':')return bad("expected colon");GltfJson v;if(!val(v))return false;if(!o.object.emplace(k,std::move(v)).second)return bad("duplicate object key");ws();if(p>=s.size())return bad("unterminated object");if(s[p]=='}'){++p;return true;}if(s[p++]!=',')return bad("expected comma");}}
    bool arr(GltfJson& o){o.type=GltfJson::Type::Array;++p;ws();if(p<s.size()&&s[p]==']'){++p;return true;}for(;;){GltfJson v;if(!val(v))return false;o.array.push_back(std::move(v));ws();if(p>=s.size())return bad("unterminated array");if(s[p]==']'){++p;return true;}if(s[p++]!=',')return bad("expected comma");}}
public:GltfJsonParser(const std::string& x,GlbError* y):s(x),e(y){}bool parse(GltfJson& o){if(!val(o))return false;ws();return p==s.size()||bad("trailing data");}
};
inline bool validateGltfJson(const std::string& t,GltfJson* out=nullptr,GlbError* e=nullptr){GltfJson r;if(!GltfJsonParser(t,e).parse(r)||r.type!=GltfJson::Type::Object){if(e&&r.type!=GltfJson::Type::Object)*e={"root must be object",0};return false;}auto*a=r.find("asset"),*v=a?a->find("version"):nullptr;if(!a||a->type!=GltfJson::Type::Object||!v||v->type!=GltfJson::Type::String||v->string!="2.0"){if(e)*e={"asset.version must be 2.0",0};return false;}for(const char*k:{"scene","scenes","nodes","meshes","skins","animations","buffers","bufferViews","accessors","materials","textures","images","samplers"}){auto*x=r.find(k);if(x&&x->type!=GltfJson::Type::Array){if(e)*e={std::string(k)+" must be array",0};return false;}}if(out)*out=std::move(r);return true;}
class GlbReader { public: static bool read(const std::vector<std::uint8_t>& b,GlbDocument& o,GlbError* e=nullptr){o={};auto bad=[&](const char*m,std::size_t p){if(e)*e={m,p};return false;};if(b.size()<12)return bad("GLB header is truncated",b.size());auto u=[&](std::size_t p){return std::uint32_t(b[p])|std::uint32_t(b[p+1])<<8|std::uint32_t(b[p+2])<<16|std::uint32_t(b[p+3])<<24;};if(u(0)!=0x46546c67u)return bad("invalid GLB magic",0);if(u(4)!=2)return bad("unsupported GLB version",4);if(u(8)!=b.size())return bad("GLB length does not match input",8);std::size_t p=12;bool j=false,n=false;while(p<b.size()){if(b.size()-p<8)return bad("GLB chunk header is truncated",p);auto z=u(p),t=u(p+4);p+=8;if(z>b.size()-p||z%4)return bad("invalid GLB chunk bounds",p-8);if(t==0x4e4f534a){if(j||p!=20)return bad("JSON chunk must be first and unique",p-8);j=true;o.json.assign((char*)b.data()+p,z);while(!o.json.empty()&&(o.json.back()==' '||o.json.back()=='\n'||o.json.back()=='\r'||o.json.back()=='\t'||o.json.back()=='\0'))o.json.pop_back();}else if(t==0x004e4942){if(!j||n)return bad("invalid BIN ordering",p-8);n=true;o.bin.assign(b.begin()+p,b.begin()+p+z);}else return bad("unknown GLB chunk type",p-8);o.chunks.push_back({t,p,z});p+=z;}if(!j)return bad("GLB has no JSON chunk",12);return true;}};

enum class GltfComponentType : std::uint32_t { Byte=5120, UnsignedByte=5121, Short=5122, UnsignedShort=5123, UnsignedInt=5125, Float=5126 };
enum class GltfAccessorKind { Scalar, Vec2, Vec3, Vec4, Mat2, Mat3, Mat4 };
struct AssetResolver { virtual ~AssetResolver()=default; virtual bool resolve(const std::string& uri,std::vector<std::uint8_t>& bytes,std::string& error)=0; };
struct GltfBuffer { std::vector<std::uint8_t> data; std::string uri; std::size_t declaredByteLength=0; };
struct GltfSparse { std::size_t count=0,indicesBufferView=static_cast<std::size_t>(-1),indicesByteOffset=0,valuesBufferView=static_cast<std::size_t>(-1),valuesByteOffset=0; GltfComponentType indicesComponentType=GltfComponentType::UnsignedShort; bool present=false; };
struct GltfBufferView { std::size_t buffer=0, byteOffset=0, byteLength=0, byteStride=0; std::uint32_t target=0; };
struct GltfAccessor { std::size_t bufferView=static_cast<std::size_t>(-1), byteOffset=0, count=0; GltfComponentType componentType=GltfComponentType::Float; GltfAccessorKind kind=GltfAccessorKind::Scalar; bool normalized=false; GltfSparse sparse; };
struct GltfPrimitive { std::map<std::string,std::size_t> attributes; std::size_t indices=static_cast<std::size_t>(-1), material=static_cast<std::size_t>(-1); };
struct GltfMesh { std::string name; std::vector<GltfPrimitive> primitives; };
struct GltfNode { std::string name; int mesh=-1, skin=-1, parent=-1; std::vector<std::size_t> children; };
struct GltfMaterial { std::string name; float baseColor[4]={1,1,1,1}; float metallic=1, roughness=1; };
struct GltfSkin { std::string name; int skeleton=-1; std::vector<std::size_t> joints; std::size_t inverseBindMatrices=static_cast<std::size_t>(-1); };
struct GltfAnimationSampler { std::size_t input=static_cast<std::size_t>(-1), output=static_cast<std::size_t>(-1); std::string interpolation="LINEAR"; };
struct GltfAnimationChannel { std::size_t sampler=0; int node=-1; std::string path; };
struct GltfAnimation { std::string name; std::vector<GltfAnimationSampler> samplers; std::vector<GltfAnimationChannel> channels; };
struct GltfDocument { std::vector<GltfBuffer> buffers; std::vector<GltfBufferView> bufferViews; std::vector<GltfAccessor> accessors; std::vector<GltfMesh> meshes; std::vector<GltfNode> nodes; std::vector<GltfMaterial> materials; std::vector<GltfSkin> skins; std::vector<GltfAnimation> animations; };
inline std::size_t accessorComponents(GltfAccessorKind k){switch(k){case GltfAccessorKind::Scalar:return 1;case GltfAccessorKind::Vec2:return 2;case GltfAccessorKind::Vec3:return 3;case GltfAccessorKind::Vec4:return 4;case GltfAccessorKind::Mat2:return 4;case GltfAccessorKind::Mat3:return 9;case GltfAccessorKind::Mat4:return 16;}return 0;}
inline std::size_t componentBytes(GltfComponentType t){switch(t){case GltfComponentType::Byte:case GltfComponentType::UnsignedByte:return 1;case GltfComponentType::Short:case GltfComponentType::UnsignedShort:return 2;case GltfComponentType::UnsignedInt:case GltfComponentType::Float:return 4;}return 0;}
inline bool parseAccessorKind(const std::string&s,GltfAccessorKind& o){if(s=="SCALAR")o=GltfAccessorKind::Scalar;else if(s=="VEC2")o=GltfAccessorKind::Vec2;else if(s=="VEC3")o=GltfAccessorKind::Vec3;else if(s=="VEC4")o=GltfAccessorKind::Vec4;else if(s=="MAT2")o=GltfAccessorKind::Mat2;else if(s=="MAT3")o=GltfAccessorKind::Mat3;else if(s=="MAT4")o=GltfAccessorKind::Mat4;else return false;return true;}
inline bool parseTypedGltf(const GltfJson& root,const std::vector<std::uint8_t>& glbBin,GltfDocument& out,GlbError* error=nullptr){
    out={};auto fail=[&](const std::string&m){if(error)*error={m,0};return false;};
    auto arr=[&](const char*k)->const std::vector<GltfJson>*{auto v=root.find(k);return v&&v->type==GltfJson::Type::Array?&v->array:nullptr;};
    auto num=[&](const GltfJson& x,const char* what,std::size_t& n){if(x.type!=GltfJson::Type::Number||x.number<0||x.number>double(std::numeric_limits<std::size_t>::max())||x.number!=std::floor(x.number))return fail(std::string(what)+" must be a non-negative integer");n=std::size_t(x.number);return true;};
    auto optIndex=[&](const GltfJson& x,const char* what,int& n){if(x.type!=GltfJson::Type::Number||x.number<0||x.number>double(std::numeric_limits<int>::max())||x.number!=std::floor(x.number))return fail(std::string(what)+" must be an index");n=int(x.number);return true;};
    if(root.type!=GltfJson::Type::Object)return fail("GLTF root must be an object");
    if(auto a=arr("buffers"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("buffer must be object");GltfBuffer b;if(auto n=x.find("uri")){if(n->type!=GltfJson::Type::String)return fail("buffer.uri must be string");b.uri=n->string;}if(auto n=x.find("byteLength")){if(!num(*n,"buffer.byteLength",b.declaredByteLength))return false;}if(out.buffers.empty()&&b.uri.empty())b.data=glbBin;out.buffers.push_back(std::move(b));}
    if(auto a=arr("bufferViews"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("bufferView must be object");GltfBufferView v;auto n=x.find("buffer");if(!n||!num(*n,"bufferView.buffer",v.buffer))return false;if(auto q=x.find("byteOffset"))if(!num(*q,"bufferView.byteOffset",v.byteOffset))return false;if(auto q=x.find("byteLength"))if(!num(*q,"bufferView.byteLength",v.byteLength))return false;if(auto q=x.find("byteStride"))if(!num(*q,"bufferView.byteStride",v.byteStride))return false;if(auto q=x.find("target")){std::size_t z;if(!num(*q,"bufferView.target",z))return false;v.target=std::uint32_t(z);}out.bufferViews.push_back(v);}
    if(auto a=arr("accessors"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("accessor must be object");GltfAccessor v;auto n=x.find("componentType"),t=x.find("type"),c=x.find("count");std::size_t ct;if(!n||!t||!c||!num(*n,"accessor.componentType",ct)||t->type!=GltfJson::Type::String||!num(*c,"accessor.count",v.count))return fail("accessor requires componentType, type and count");v.componentType=static_cast<GltfComponentType>(std::uint32_t(ct));if(componentBytes(v.componentType)==0)return fail("unsupported accessor component type");if(!parseAccessorKind(t->string,v.kind))return fail("unsupported accessor type");if(auto q=x.find("bufferView"))if(!num(*q,"accessor.bufferView",v.bufferView))return false;if(auto q=x.find("byteOffset"))if(!num(*q,"accessor.byteOffset",v.byteOffset))return false;if(auto q=x.find("normalized")){if(q->type!=GltfJson::Type::Bool)return fail("accessor.normalized must be bool");v.normalized=q->boolean;}if(auto sp=x.find("sparse")){if(sp->type!=GltfJson::Type::Object)return fail("accessor.sparse must be object");v.sparse.present=true;auto sn=sp->find("count"),si=sp->find("indices"),sv=sp->find("values");if(!sn||!si||!sv||!num(*sn,"sparse.count",v.sparse.count)||si->type!=GltfJson::Type::Object||sv->type!=GltfJson::Type::Object)return fail("sparse requires count, indices and values");auto ib=si->find("bufferView"),ic=si->find("componentType"),vb=sv->find("bufferView");std::size_t ict;if(!ib||!ic||!vb||!num(*ib,"sparse.indices.bufferView",v.sparse.indicesBufferView)||!num(*vb,"sparse.values.bufferView",v.sparse.valuesBufferView)||!num(*ic,"sparse.indices.componentType",ict))return false;v.sparse.indicesComponentType=static_cast<GltfComponentType>(ict);if(v.sparse.indicesComponentType!=GltfComponentType::UnsignedByte&&v.sparse.indicesComponentType!=GltfComponentType::UnsignedShort&&v.sparse.indicesComponentType!=GltfComponentType::UnsignedInt)return fail("sparse indices component type must be unsigned");if(auto z=si->find("byteOffset"))if(!num(*z,"sparse.indices.byteOffset",v.sparse.indicesByteOffset))return false;if(auto z=sv->find("byteOffset"))if(!num(*z,"sparse.values.byteOffset",v.sparse.valuesByteOffset))return false;}out.accessors.push_back(v);}
    if(auto a=arr("meshes"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("mesh must be object");GltfMesh m;if(auto q=x.find("name")){if(q->type!=GltfJson::Type::String)return fail("mesh.name must be string");m.name=q->string;}auto p=x.find("primitives");if(!p||p->type!=GltfJson::Type::Array)return fail("mesh.primitives must be array");for(const auto&z:p->array){if(z.type!=GltfJson::Type::Object)return fail("primitive must be object");GltfPrimitive r;auto at=z.find("attributes");if(!at||at->type!=GltfJson::Type::Object)return fail("primitive.attributes must be object");for(const auto&kv:at->object){if(!num(kv.second,"primitive attribute",r.attributes[kv.first]))return false;}if(auto q=z.find("indices"))if(!num(*q,"primitive.indices",r.indices))return false;if(auto q=z.find("material"))if(!num(*q,"primitive.material",r.material))return false;m.primitives.push_back(std::move(r));}out.meshes.push_back(std::move(m));}
    if(auto a=arr("nodes"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("node must be object");GltfNode n;if(auto q=x.find("name")){if(q->type!=GltfJson::Type::String)return fail("node.name must be string");n.name=q->string;}if(auto q=x.find("mesh"))if(!optIndex(*q,"node.mesh",n.mesh))return false;if(auto q=x.find("skin"))if(!optIndex(*q,"node.skin",n.skin))return false;if(auto q=x.find("children")){if(q->type!=GltfJson::Type::Array)return fail("node.children must be array");for(const auto&z:q->array){std::size_t i;if(!num(z,"node child",i))return false;n.children.push_back(i);}}out.nodes.push_back(std::move(n));}
    for(std::size_t i=0;i<out.nodes.size();++i)for(auto child:out.nodes[i].children){if(child>=out.nodes.size())return fail("node child index out of range");if(out.nodes[child].parent!=-1)return fail("node has multiple parents");out.nodes[child].parent=int(i);}
    if(auto a=arr("materials"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("material must be object");GltfMaterial m;if(auto q=x.find("name")){if(q->type!=GltfJson::Type::String)return fail("material.name must be string");m.name=q->string;}if(auto p=x.find("pbrMetallicRoughness")){if(p->type!=GltfJson::Type::Object)return fail("pbrMetallicRoughness must be object");if(auto q=p->find("baseColorFactor")){if(q->type!=GltfJson::Type::Array||q->array.size()!=4)return fail("baseColorFactor must have four values");for(int i=0;i<4;++i){if(q->array[i].type!=GltfJson::Type::Number)return fail("baseColorFactor values must be numbers");m.baseColor[i]=float(q->array[i].number);}}if(auto q=p->find("metallicFactor")){if(q->type!=GltfJson::Type::Number)return fail("metallicFactor must be number");m.metallic=float(q->number);}if(auto q=p->find("roughnessFactor")){if(q->type!=GltfJson::Type::Number)return fail("roughnessFactor must be number");m.roughness=float(q->number);}}out.materials.push_back(m);}
    if(auto a=arr("skins"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("skin must be object");GltfSkin s;if(auto q=x.find("name")){if(q->type!=GltfJson::Type::String)return fail("skin.name must be string");s.name=q->string;}if(auto q=x.find("skeleton"))if(!optIndex(*q,"skin.skeleton",s.skeleton))return false;auto j=x.find("joints");if(!j||j->type!=GltfJson::Type::Array)return fail("skin.joints must be array");for(const auto&z:j->array){std::size_t i;if(!num(z,"skin joint",i))return false;s.joints.push_back(i);}if(auto q=x.find("inverseBindMatrices"))if(!num(*q,"skin.inverseBindMatrices",s.inverseBindMatrices))return false;out.skins.push_back(std::move(s));}
    if(auto a=arr("animations"))for(const auto&x:*a){if(x.type!=GltfJson::Type::Object)return fail("animation must be object");GltfAnimation an;if(auto q=x.find("name")){if(q->type!=GltfJson::Type::String)return fail("animation.name must be string");an.name=q->string;}auto ss=x.find("samplers");if(!ss||ss->type!=GltfJson::Type::Array)return fail("animation.samplers must be array");for(const auto&z:ss->array){if(z.type!=GltfJson::Type::Object)return fail("animation sampler must be object");GltfAnimationSampler s;auto i=z.find("input"),o=z.find("output");if(!i||!o||!num(*i,"animation sampler input",s.input)||!num(*o,"animation sampler output",s.output))return false;if(auto q=z.find("interpolation")){if(q->type!=GltfJson::Type::String)return fail("animation interpolation must be string");s.interpolation=q->string;}an.samplers.push_back(std::move(s));}auto ch=x.find("channels");if(!ch||ch->type!=GltfJson::Type::Array)return fail("animation.channels must be array");for(const auto&z:ch->array){if(z.type!=GltfJson::Type::Object)return fail("animation channel must be object");GltfAnimationChannel c;auto si=z.find("sampler"),tar=z.find("target");if(!si||!num(*si,"animation channel sampler",c.sampler)||!tar||tar->type!=GltfJson::Type::Object)return fail("animation channel target missing");auto no=tar->find("node"),pa=tar->find("path");if(no&&!optIndex(*no,"animation target node",c.node))return false;if(!pa||pa->type!=GltfJson::Type::String)return fail("animation target path missing");c.path=pa->string;an.channels.push_back(std::move(c));}out.animations.push_back(std::move(an));}
    for(const auto& v:out.bufferViews) if(v.buffer>=out.buffers.size()) return fail("bufferView.buffer index out of range");
    for(const auto& a:out.accessors) if(a.bufferView!=static_cast<std::size_t>(-1)&&a.bufferView>=out.bufferViews.size()) return fail("accessor.bufferView index out of range");
    for(const auto& m:out.meshes) for(const auto& p:m.primitives){
        for(const auto& kv:p.attributes) if(kv.second>=out.accessors.size()) return fail("primitive attribute accessor index out of range");
        if(p.indices!=static_cast<std::size_t>(-1)&&p.indices>=out.accessors.size()) return fail("primitive.indices accessor index out of range");
        if(p.material!=static_cast<std::size_t>(-1)&&p.material>=out.materials.size()) return fail("primitive.material index out of range");
    }
    for(const auto& n:out.nodes){
        if(n.mesh>=0&&std::size_t(n.mesh)>=out.meshes.size()) return fail("node.mesh index out of range");
        if(n.skin>=0&&std::size_t(n.skin)>=out.skins.size()) return fail("node.skin index out of range");
    }
    for(const auto& s:out.skins){
        if(s.skeleton>=0&&std::size_t(s.skeleton)>=out.nodes.size()) return fail("skin.skeleton index out of range");
        for(auto j:s.joints) if(j>=out.nodes.size()) return fail("skin joint index out of range");
        if(s.inverseBindMatrices!=static_cast<std::size_t>(-1)&&s.inverseBindMatrices>=out.accessors.size()) return fail("skin.inverseBindMatrices index out of range");
    }
    for(const auto& a:out.animations){
        for(const auto& s:a.samplers) if(s.input>=out.accessors.size()||s.output>=out.accessors.size()) return fail("animation sampler accessor index out of range");
        for(const auto& c:a.channels) if(c.sampler>=a.samplers.size()||(c.node>=0&&std::size_t(c.node)>=out.nodes.size())) return fail("animation channel reference out of range");
    }
    return true;
}
inline bool decodeAccessor(const GltfDocument& doc,std::size_t ai,std::vector<float>& out,GlbError* error=nullptr){
 out.clear(); auto fail=[&](const std::string&m){if(error)*error={m,0};return false;};
 if(ai>=doc.accessors.size())return fail("accessor index out of range");
 const auto&a=doc.accessors[ai]; const auto comps=accessorComponents(a.kind), cb=componentBytes(a.componentType);
 if(!comps||!cb)return fail("invalid accessor format");
 if(a.count>std::numeric_limits<std::size_t>::max()/comps)return fail("accessor element count overflows size");
 out.assign(a.count*comps,0.f);
 auto view=[&](std::size_t vi,const std::uint8_t*&ptr,std::size_t off,std::size_t need){
  if(vi>=doc.bufferViews.size())return false; const auto&v=doc.bufferViews[vi];
  if(v.buffer>=doc.buffers.size()||v.byteOffset>doc.buffers[v.buffer].data.size())return false;
  const auto&buf=doc.buffers[v.buffer].data; if(off>buf.size()-v.byteOffset)return false;
  const auto base=v.byteOffset+off; if(need>buf.size()-base)return false;
  if(v.byteLength&&off>v.byteLength)return false; if(v.byteLength&&need>v.byteLength-off)return false;
  ptr=buf.data()+base; return true;
 };
 auto read=[&](const std::uint8_t*p,GltfComponentType t,bool norm){switch(t){
  case GltfComponentType::Byte:{auto x=static_cast<std::int8_t>(*p);return norm?std::max(-1.f,float(x)/127.f):float(x);}
  case GltfComponentType::UnsignedByte:return norm?float(*p)/255.f:float(*p);
  case GltfComponentType::Short:{std::int16_t x;std::memcpy(&x,p,2);return norm?std::max(-1.f,float(x)/32767.f):float(x);}
  case GltfComponentType::UnsignedShort:{std::uint16_t x;std::memcpy(&x,p,2);return norm?float(x)/65535.f:float(x);}
  case GltfComponentType::UnsignedInt:{std::uint32_t x;std::memcpy(&x,p,4);return float(x);}
  case GltfComponentType::Float:{float x;std::memcpy(&x,p,4);return x;}}
  return 0.f;};
 if(a.bufferView!=static_cast<std::size_t>(-1)){
  const auto&v=doc.bufferViews[a.bufferView]; const std::size_t packed=comps*cb; const std::size_t stride=v.byteStride?v.byteStride:packed;
  if(stride<packed)return fail("accessor byteStride is smaller than element size");
  if(a.count>1 && stride>std::numeric_limits<std::size_t>::max()/(a.count-1))return fail("accessor stride overflows size");
  const auto span=a.count?((a.count-1)*stride):0; if(span>std::numeric_limits<std::size_t>::max()-packed)return fail("accessor span overflows size");
  const std::uint8_t*dummy=nullptr; if(a.count&&!view(a.bufferView,dummy,a.byteOffset,span+packed))return fail("accessor data exceeds buffer");
  for(std::size_t i=0;i<a.count;++i)for(std::size_t j=0;j<comps;++j){const auto off=a.byteOffset+i*stride+j*cb;const std::uint8_t*q=nullptr;if(!view(a.bufferView,q,off,cb))return fail("accessor data exceeds buffer");out[i*comps+j]=read(q,a.componentType,a.normalized);}
 }
 if(a.sparse.present){
  if(a.sparse.count>a.count)return fail("sparse.count exceeds accessor.count"); const std::size_t ib=componentBytes(a.sparse.indicesComponentType); if(!ib)return fail("invalid sparse index format");
  if(a.sparse.count>1&&ib>std::numeric_limits<std::size_t>::max()/(a.sparse.count-1))return fail("sparse index span overflows size");
  for(std::size_t k=0;k<a.sparse.count;++k){const std::uint8_t*ip=nullptr;if(!view(a.sparse.indicesBufferView,ip,a.sparse.indicesByteOffset+k*ib,ib))return fail("sparse indices exceed buffer");const std::size_t idx=std::size_t(read(ip,a.sparse.indicesComponentType,false));if(idx>=a.count)return fail("sparse index out of range");
   if(k>std::numeric_limits<std::size_t>::max()/comps||k*comps>std::numeric_limits<std::size_t>::max()/cb)return fail("sparse value span overflows size");
   for(std::size_t j=0;j<comps;++j){const auto off=a.sparse.valuesByteOffset+(k*comps+j)*cb;const std::uint8_t*vp=nullptr;if(!view(a.sparse.valuesBufferView,vp,off,cb))return fail("sparse values exceed buffer");out[idx*comps+j]=read(vp,a.componentType,a.normalized);}
  }
 }
 return true;
}
inline bool resolveGltfResources(const GltfJson& root,const std::vector<std::uint8_t>& glbBin,AssetResolver& resolver,GltfDocument& out,GlbError* error=nullptr){if(!parseTypedGltf(root,glbBin,out,error))return false;for(auto&b:out.buffers)if(!b.uri.empty()){std::vector<std::uint8_t> bytes;std::string msg;if(b.uri.rfind("data:",0)==0){auto comma=b.uri.find(',');if(comma==std::string::npos){if(error)*error={"invalid data URI",0};return false;}auto payload=b.uri.substr(comma+1);if(b.uri.substr(0,comma).find(";base64")!=std::string::npos){static const char*hex="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(std::size_t i=0;i<payload.size();){std::uint32_t v=0;int n=0;for(int z=0;z<4&&i<payload.size();++z){auto q=std::string(hex).find(payload[i++]);if(q==std::string::npos){if(payload[i-1]=='=')continue;if(error)*error={"invalid base64 data URI",0};return false;}v=(v<<6)|std::uint32_t(q);++n;}for(int z=1;z<n;++z)bytes.push_back(std::uint8_t(v>>(8*(n-z-1))));}}else bytes.assign(payload.begin(),payload.end());}else if(!resolver.resolve(b.uri,bytes,msg)){if(error)*error={msg.empty()?"asset resolver failed":msg,0};return false;}b.data=std::move(bytes);if(b.declaredByteLength&&b.data.size()<b.declaredByteLength){if(error)*error={"resolved buffer shorter than byteLength",0};return false;}}return true;}

}
