#pragma once
#include <algorithm>
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <memory>
#include <typeindex>
#include <limits>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

namespace sankur::sdk {
using Entity = std::uint32_t;
constexpr Entity kInvalidEntity = 0;

class Registry {
public:
    Entity create() {
        if (next_ == kInvalidEntity || next_ == std::numeric_limits<Entity>::max()) return kInvalidEntity;
        const Entity e = next_++; alive_.push_back(e); return e;
    }
    void destroy(Entity e) { if (!valid(e)) return; alive_.erase(std::remove(alive_.begin(), alive_.end(), e), alive_.end()); for (auto& f : removers_) f(e); }
    bool valid(Entity e) const { return std::find(alive_.begin(), alive_.end(), e) != alive_.end(); }
    const std::vector<Entity>& entities() const noexcept { return alive_; }

    template<class T, class... Args> T& emplace(Entity e, Args&&... args) {
        // Rejecting invalid ownership here avoids silently creating orphaned
        // components that can never be visited by each(). Callers must create
        // an entity before attaching components.
        if (!valid(e)) throw std::invalid_argument("cannot emplace a component on an invalid entity");
        return storage<T>().data[e] = T{std::forward<Args>(args)...};
    }
    template<class T> bool has(Entity e) const { const auto* s = findStorage<T>(); return s && s->data.find(e) != s->data.end(); }
    template<class T> T* tryGet(Entity e) { auto* s = findStorage<T>(); if (!s) return nullptr; auto i=s->data.find(e); return i==s->data.end()?nullptr:&i->second; }
    template<class T> const T* tryGet(Entity e) const { const auto* s = findStorage<T>(); if (!s) return nullptr; auto i=s->data.find(e); return i==s->data.end()?nullptr:&i->second; }
    template<class T> void remove(Entity e) { if (auto* s=findStorage<T>()) s->data.erase(e); }

    template<class... Ts, class Fn> void each(Fn&& fn) {
        for (Entity e : alive_) if ((has<Ts>(e) && ...)) fn(e, *tryGet<Ts>(e)...);
    }
private:
    struct StorageBase { virtual ~StorageBase() = default; virtual void erase(Entity)=0; };
    template<class T> struct Storage : StorageBase { std::unordered_map<Entity,T> data; void erase(Entity e) override { data.erase(e); } };
    template<class T> Storage<T>& storage() { for (auto& s: stores_) if (s.type==typeid(T)) return *static_cast<Storage<T>*>(s.ptr.get()); stores_.push_back({typeid(T), std::unique_ptr<StorageBase>(new Storage<T>)}); removers_.push_back([this](Entity e){ this->remove<T>(e); }); return *static_cast<Storage<T>*>(stores_.back().ptr.get()); }
    template<class T> Storage<T>* findStorage() { for (auto& s:stores_) if(s.type==typeid(T)) return static_cast<Storage<T>*>(s.ptr.get()); return nullptr; }
    template<class T> const Storage<T>* findStorage() const { for (const auto& s:stores_) if(s.type==typeid(T)) return static_cast<const Storage<T>*>(s.ptr.get()); return nullptr; }
    struct Entry { std::type_index type; std::unique_ptr<StorageBase> ptr; };
    Entity next_=1; std::vector<Entity> alive_; std::vector<Entry> stores_; std::vector<std::function<void(Entity)>> removers_;
};
}
