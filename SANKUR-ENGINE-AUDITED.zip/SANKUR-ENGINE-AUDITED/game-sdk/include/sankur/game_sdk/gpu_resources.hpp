#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
namespace sankur::sdk {
enum class GpuResourceKind { Buffer, Texture, Sampler };
enum class GpuResourceState { Created, Uploading, Resident, Failed };
struct GpuResourceHandle { std::uint64_t id=0; GpuResourceKind kind=GpuResourceKind::Buffer; std::uint32_t generation=0; explicit operator bool() const noexcept { return id != 0; } };
struct GpuResourceDesc { GpuResourceKind kind=GpuResourceKind::Buffer; std::size_t byteSize=0; std::uint32_t width=0,height=0; std::string debugName; };
class GpuResourceRegistry {
public:
 GpuResourceHandle create(const GpuResourceDesc& d){if(d.byteSize==0&&d.kind==GpuResourceKind::Buffer)return {};auto h=GpuResourceHandle{next_++,d.kind,1};resources_.emplace(h.id,Entry{d,GpuResourceState::Created,h.generation});return h;}
 bool destroy(GpuResourceHandle h)noexcept{auto i=resources_.find(h.id);if(i==resources_.end()||!matches(i->second,h))return false;resources_.erase(i);return true;}
 const GpuResourceDesc* describe(GpuResourceHandle h)const noexcept{auto i=resources_.find(h.id);return i==resources_.end()||!matches(i->second,h)?nullptr:&i->second.desc;}
 GpuResourceState state(GpuResourceHandle h)const noexcept{auto i=resources_.find(h.id);return i==resources_.end()||!matches(i->second,h)?GpuResourceState::Failed:i->second.state;}
 bool alive(GpuResourceHandle h)const noexcept{auto i=resources_.find(h.id);return i!=resources_.end()&&matches(i->second,h);}
 bool beginUpload(GpuResourceHandle h,std::string* e=nullptr){return transition(h,GpuResourceState::Uploading,e);}
 bool completeUpload(GpuResourceHandle h,std::string* e=nullptr){return transition(h,GpuResourceState::Resident,e);}
 bool failUpload(GpuResourceHandle h,std::string* e=nullptr){return transition(h,GpuResourceState::Failed,e);}
 bool transition(GpuResourceHandle h,GpuResourceState n,std::string* e=nullptr){auto i=resources_.find(h.id);if(i==resources_.end()||!matches(i->second,h))return reject(e,"resource handle is stale or unknown");auto c=i->second.state;bool ok=(c==GpuResourceState::Created&&n==GpuResourceState::Uploading)||(c==GpuResourceState::Uploading&&(n==GpuResourceState::Resident||n==GpuResourceState::Failed));if(!ok)return reject(e,"invalid resource state transition");i->second.state=n;if(e)e->clear();return true;}
 std::size_t size()const noexcept{return resources_.size();}
private:
 struct Entry{GpuResourceDesc desc;GpuResourceState state;std::uint32_t generation;};
 static bool matches(const Entry&e,GpuResourceHandle h)noexcept{return e.generation==h.generation&&e.desc.kind==h.kind;}
 static bool reject(std::string*e,const char*m){if(e)*e=m;return false;}
 std::uint64_t next_=1;std::unordered_map<std::uint64_t,Entry> resources_;
};
enum class MaterialSlot{BaseColor,Normal,MetallicRoughness,Occlusion,Emissive};
struct MaterialBinding{MaterialSlot slot=MaterialSlot::BaseColor;GpuResourceHandle texture{};std::uint32_t samplerIndex=0;};
struct Material{std::string name;std::vector<MaterialBinding> bindings;float baseColor[4]={1,1,1,1};float metallic=1,roughness=1;};
class MaterialBinder{public:bool bind(const Material&m,const GpuResourceRegistry&r,std::string&e)const{for(const auto&b:m.bindings){if(!b.texture){e="material binding has an invalid texture handle";return false;}const auto*d=r.describe(b.texture);if(!d||d->kind!=GpuResourceKind::Texture){e="material binding references a missing, stale, or non-texture resource";return false;}if(r.state(b.texture)!=GpuResourceState::Resident){e="material binding references a texture that is not resident";return false;}}e.clear();return true;}};
}
