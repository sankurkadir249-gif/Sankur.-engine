#pragma once
#include <algorithm>
#include <chrono>
namespace sankur::sdk {
class GameLifecycle { public: virtual ~GameLifecycle()=default; virtual void onStart(){} virtual void onFixedUpdate(double){} virtual void onUpdate(double){} virtual void onStop(){} };
class FixedTimestepLoop {
public:
 explicit FixedTimestepLoop(double step=1.0/60.0, double maxFrame=0.25):step_(step),maxFrame_(maxFrame){}
 void reset() noexcept { accumulator_=0; }
 int advance(double frameSeconds, GameLifecycle& game) { const double frame=std::clamp(frameSeconds,0.0,maxFrame_); accumulator_+=frame; int updates=0; while(accumulator_>=step_){game.onFixedUpdate(step_); accumulator_-=step_; ++updates;} game.onUpdate(frame); return updates; }
 double interpolationAlpha() const noexcept { return accumulator_/step_; } double step() const noexcept{return step_;}
private: double step_,maxFrame_,accumulator_=0;
};
}
