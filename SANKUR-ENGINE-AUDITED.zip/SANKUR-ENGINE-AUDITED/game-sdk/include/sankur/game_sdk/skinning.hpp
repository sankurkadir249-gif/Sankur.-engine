#pragma once
#include "animation.hpp"
#include <array>
#include <algorithm>
namespace sankur::sdk {
struct Mat4 { float m[16]{}; static Mat4 identity(){Mat4 r; r.m[0]=r.m[5]=r.m[10]=r.m[15]=1; return r;} Vec3 transformPoint(Vec3 v)const{return{m[0]*v.x+m[4]*v.y+m[8]*v.z+m[12],m[1]*v.x+m[5]*v.y+m[9]*v.z+m[13],m[2]*v.x+m[6]*v.y+m[10]*v.z+m[14]};} };
inline Mat4 multiply(const Mat4&a,const Mat4&b){Mat4 r;for(int c=0;c<4;++c)for(int row=0;row<4;++row)for(int k=0;k<4;++k)r.m[c*4+row]+=a.m[k*4+row]*b.m[c*4+k];return r;}
struct SkinBinding { std::vector<int> joints; int skeletonRoot=-1; };
struct SkinInfluences { std::array<std::uint16_t,4> joints{}; std::array<float,4> weights{}; };
inline Vec3 skinPoint(Vec3 position,const SkinInfluences& in,const std::vector<Mat4>& joints){float sum=0;for(float w:in.weights)if(std::isfinite(w)&&w>0)sum+=w; if(sum<=1e-20f)return position;Vec3 out{};for(int i=0;i<4;++i){const float w=(std::isfinite(in.weights[i])&&in.weights[i]>0)?in.weights[i]/sum:0; if(w>0&&in.joints[i]<joints.size())out=out+joints[in.joints[i]].transformPoint(position)*w;}return out;}
inline std::vector<Mat4> buildJointMatrices(const std::vector<int>& parents,const std::vector<Mat4>& global,const Mat4& inverseBind,const std::vector<Mat4>& inverseBinds){std::vector<Mat4> out(global.size(),Mat4::identity());for(std::size_t i=0;i<global.size();++i)out[i]=multiply(global[i],i<inverseBinds.size()?inverseBinds[i]:Mat4::identity());return out;}
}
