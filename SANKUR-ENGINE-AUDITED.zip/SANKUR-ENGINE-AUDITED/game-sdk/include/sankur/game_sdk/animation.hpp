#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
namespace sankur::sdk {
struct AnimationChannel { int node=-1; enum class Path { Translation, Rotation, Scale, Weights }; Path path=Path::Translation; };
struct AnimationClip { std::string name; std::vector<AnimationChannel> channels; float duration=0; };
struct Vec3 { float x=0,y=0,z=0; Vec3 operator+(Vec3 b)const{return{x+b.x,y+b.y,z+b.z};} Vec3 operator-(Vec3 b)const{return{x-b.x,y-b.y,z-b.z};} Vec3 operator*(float s)const{return{x*s,y*s,z*s};} };
struct Quat { float x=0,y=0,z=0,w=1; };
inline float dot(Quat a,Quat b){return a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w;}
inline Quat normalize(Quat q){float n=std::sqrt(dot(q,q));return n>1e-20f?Quat{q.x/n,q.y/n,q.z/n,q.w/n}:Quat{};}
inline Quat nlerp(Quat a,Quat b,float t){if(dot(a,b)<0)b={-b.x,-b.y,-b.z,-b.w};return normalize({a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t,a.w+(b.w-a.w)*t});}
enum class Interpolation { Step, Linear, CubicSpline };
template<class T> struct KeyframeTrack { std::vector<float> times; std::vector<T> values; Interpolation interpolation=Interpolation::Linear; };
inline std::size_t keyIndex(const std::vector<float>& t,float time){if(t.size()<2)return 0;auto i=std::upper_bound(t.begin(),t.end(),time);return i==t.begin()?0:std::min<std::size_t>(std::size_t(i-t.begin()-1),t.size()-2);}
inline float hermite(float a,float out,float b,float in,float u,float dt){float h00=2*u*u*u-3*u*u+1,h10=u*u*u-2*u*u+u,h01=-2*u*u*u+3*u*u,h11=u*u*u-u*u;return h00*a+h10*dt*out+h01*b+h11*dt*in;}
inline Vec3 hermite(Vec3 a,Vec3 out,Vec3 b,Vec3 in,float u,float dt){return{hermite(a.x,out.x,b.x,in.x,u,dt),hermite(a.y,out.y,b.y,in.y,u,dt),hermite(a.z,out.z,b.z,in.z,u,dt)};}
inline Quat hermite(Quat a,Quat out,Quat b,Quat in,float u,float dt){return normalize({hermite(a.x,out.x,b.x,in.x,u,dt),hermite(a.y,out.y,b.y,in.y,u,dt),hermite(a.z,out.z,b.z,in.z,u,dt),hermite(a.w,out.w,b.w,in.w,u,dt)});}
template<class T> inline T trackValue(const KeyframeTrack<T>& tr,std::size_t key){return tr.interpolation==Interpolation::CubicSpline&&tr.values.size()>=tr.times.size()*3?tr.values[key*3+1]:tr.values[key];}
template<class T> inline T sampleTrack(const KeyframeTrack<T>& tr,float time){if(tr.times.empty()||tr.values.empty())return T{};const std::size_t n=tr.times.size();const bool cubic=tr.interpolation==Interpolation::CubicSpline&&tr.values.size()>=n*3;if(n==1||time<=tr.times[0])return trackValue(tr,0);if(time>=tr.times[n-1])return trackValue(tr,n-1);const auto i=keyIndex(tr.times,time);const float dt=tr.times[i+1]-tr.times[i],u=dt>0?(time-tr.times[i])/dt:0;if(tr.interpolation==Interpolation::Step)return trackValue(tr,i);if(cubic)return hermite(tr.values[i*3+1],tr.values[i*3+2],tr.values[(i+1)*3+1],tr.values[(i+1)*3],u,dt);return tr.values[i]+(tr.values[i+1]-tr.values[i])*u;}
inline float sample(const KeyframeTrack<float>& tr,float time){return sampleTrack(tr,time);} inline Vec3 sample(const KeyframeTrack<Vec3>& tr,float time){return sampleTrack(tr,time);} 
inline Quat sample(const KeyframeTrack<Quat>& tr,float time){if(tr.times.empty()||tr.values.empty())return{};const std::size_t n=tr.times.size();const bool cubic=tr.interpolation==Interpolation::CubicSpline&&tr.values.size()>=n*3;if(n==1||time<=tr.times[0])return normalize(trackValue(tr,0));if(time>=tr.times[n-1])return normalize(trackValue(tr,n-1));const auto i=keyIndex(tr.times,time);const float u=(time-tr.times[i])/(tr.times[i+1]-tr.times[i]);if(tr.interpolation==Interpolation::Step)return normalize(trackValue(tr,i));if(cubic)return hermite(tr.values[i*3+1],tr.values[i*3+2],tr.values[(i+1)*3+1],tr.values[(i+1)*3],u,tr.times[i+1]-tr.times[i]);return nlerp(tr.values[i],tr.values[i+1],u);}
}
