#pragma once
#include <array>
#include <cstdint>
#include <string_view>
namespace sankur::sdk {
enum class Key:std::uint8_t { Up,Down,Left,Right,Action,Cancel, Count };
class InputSnapshot { public: void beginFrame(){previous_=current_; axes_=nextAxes_;} void set(Key k,bool down){current_[static_cast<size_t>(k)]=down;} void setAxis(std::string_view name,float value){if(name=="move_x") nextAxes_[0]=value; else if(name=="move_y") nextAxes_[1]=value;} bool down(Key k)const{return current_[static_cast<size_t>(k)];} bool pressed(Key k)const{return down(k)&&!previous_[static_cast<size_t>(k)];} bool released(Key k)const{return !down(k)&&previous_[static_cast<size_t>(k)];} float axisX()const{return axes_[0];} float axisY()const{return axes_[1];} private: std::array<bool,static_cast<size_t>(Key::Count)> current_{} ,previous_{}; std::array<float,2> axes_{} ,nextAxes_{};};
class InputSource { public: virtual ~InputSource()=default; virtual void poll(InputSnapshot&)=0; };
}
