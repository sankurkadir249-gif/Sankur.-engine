#pragma once
#include <cstdint>
#include <limits>
#include <string>
#include <unordered_set>
namespace sankur::sdk {
enum class GraphicsApi{None,OpenGLES31,Vulkan12};
struct GpuFeatureReport{GraphicsApi api=GraphicsApi::None;std::string deviceName;std::uint32_t vendorId=0,apiMajor=0,apiMinor=0;bool supportsCompute=false,supportsInstancing=false,supportsTextureArrays=false,supportsAstc=false,supportsAnisotropy=false;};
enum class SurfaceState{NoSurface,Available,Paused,Lost};
enum class ContextState{Uninitialized,Ready,ContextLost,Recreating,Failed};
struct FramePacingConfig{std::uint32_t maxFramesInFlight=2;std::uint64_t refreshPeriodNs=16666667;};
struct FrameToken{std::uint64_t serial=0,deadlineNs=0;explicit operator bool()const noexcept{return serial!=0;}};
class AndroidFramePacer{
public:
 explicit AndroidFramePacer(FramePacingConfig c={}):config_(c){normalize();}
 void configure(FramePacingConfig c){config_=c;normalize();}
 FramePacingConfig config()const noexcept{return config_;}
 FrameToken begin(std::uint64_t nowNs){
  if(active_.size()>=config_.maxFramesInFlight)return {};
  const auto serial=++serial_; active_.insert(serial);
  const auto period=config_.refreshPeriodNs;
  const auto deadline=nowNs>std::numeric_limits<std::uint64_t>::max()-period?std::numeric_limits<std::uint64_t>::max():nowNs+period;
  return FrameToken{serial,deadline};
 }
 bool end(FrameToken t){
  if(!t)return false;
  auto i=active_.find(t.serial); if(i==active_.end())return false;
  active_.erase(i); lastEnded_=t.serial; return true;
 }
 std::uint32_t inFlight()const noexcept{return static_cast<std::uint32_t>(active_.size());}
private:
 void normalize()noexcept{if(!config_.maxFramesInFlight)config_.maxFramesInFlight=1;}
 FramePacingConfig config_{}; std::uint64_t serial_=0,lastEnded_=0; std::unordered_set<std::uint64_t> active_;
};
class AndroidGpuLifecycle{public:
 void attachNativeWindow(void*w)noexcept{nativeWindow_=w;if(w)onSurfaceCreated();}
 void detachNativeWindow()noexcept{nativeWindow_=nullptr;onSurfaceDestroyed();}
 void*nativeWindow()const noexcept{return nativeWindow_;}
 SurfaceState surface()const noexcept{return surface_;}
 ContextState context()const noexcept{return context_;}
 void onSurfaceCreated(){surface_=SurfaceState::Available;if(context_==ContextState::Uninitialized||context_==ContextState::ContextLost)context_=ContextState::Recreating;}
 void onSurfaceDestroyed(){surface_=nativeWindow_?SurfaceState::Lost:SurfaceState::NoSurface;context_=ContextState::ContextLost;}
 void onPause(){if(surface_==SurfaceState::Available)surface_=SurfaceState::Paused;}
 void onResume(){if(surface_==SurfaceState::Paused)surface_=SurfaceState::Available;}
 void markContextReady(){if(surface_==SurfaceState::Available&&context_==ContextState::Recreating)context_=ContextState::Ready;}
 void markContextLost(){context_=ContextState::ContextLost;}
 void markFailed(){context_=ContextState::Failed;}
private:SurfaceState surface_=SurfaceState::NoSurface;ContextState context_=ContextState::Uninitialized;void*nativeWindow_=nullptr;
};
extern "C" inline void sankur_android_surface_created(void*p,void*w=nullptr){if(p){auto*l=static_cast<AndroidGpuLifecycle*>(p);if(w)l->attachNativeWindow(w);else l->onSurfaceCreated();}}
extern "C" inline void sankur_android_surface_destroyed(void*p){if(p)static_cast<AndroidGpuLifecycle*>(p)->detachNativeWindow();}
extern "C" inline void sankur_android_pause(void*p){if(p)static_cast<AndroidGpuLifecycle*>(p)->onPause();}
extern "C" inline void sankur_android_resume(void*p){if(p)static_cast<AndroidGpuLifecycle*>(p)->onResume();}
}
