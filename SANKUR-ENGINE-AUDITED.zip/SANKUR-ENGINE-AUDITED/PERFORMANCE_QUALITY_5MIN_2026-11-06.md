# PBR Quality + FPS Soak — 2026-11-06

The Release quality build ran for 320 seconds (5 minutes 20 seconds), completing 212 runs and 212,000 measured frames. The workload exercised 5,000 entities and 30,000 CPU-skinned vertices. The benchmark is CPU/software-Vulkan workload measurement; it is not a visual GPU result.

{
  "runs": 212,
  "frames": 212000,
  "fps_min": 558.288,
  "fps_avg": 732.7932688679246,
  "fps_median": 738.1185,
  "fps_max": 785.984,
  "frame_avg_ms_mean": 1.367127358490566,
  "frame_p95_ms_mean": 1.7534811320754717,
  "frame_p99_ms_mean": 2.1281556603773586
}

Shader validation covered Vulkan and GLES 3.1 default/mobile feature variants.
