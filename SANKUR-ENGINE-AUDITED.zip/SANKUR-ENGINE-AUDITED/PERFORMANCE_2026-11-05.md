# SANKUR PERFORMANCE RUN — 2026-11-05

## Workload

The benchmark ran for 1,221 seconds (20 minutes and 21 seconds), completing 91 runs of 1,000 frames each: 91,000 measured frames in total. Each frame exercised 5,000 ECS entities, 30,000 CPU-skinned vertices, animation sampling, deterministic cull/sort/composite work, and a real Vulkan command-buffer submission through the existing backend.

The Vulkan device reported by this sandbox was `llvmpipe (LLVM 20.1.2, 256 bits)`. This is software Vulkan rendering, not a Mali, Adreno, or PowerVR mobile GPU. The benchmark reports Vulkan queue-submission wall time separately; it must not be interpreted as hardware GPU execution time.

## Aggregate results

| Metric | Result |
|---|---:|
| Runs | 91 |
| Measured frames | 91,000 |
| Duration | 1,221 s |
| FPS minimum across runs | 67.171 |
| FPS average across runs | 78.800 |
| FPS median across runs | 79.221 |
| FPS maximum across runs | 81.128 |
| Mean frame time | 12.699 ms |
| Mean p95 frame time | 14.480 ms |
| Mean p99 frame time | 16.761 ms |
| Mean Vulkan queue-submit total per 1,000-frame run | 151.978 ms |

The measured workload stayed above 60 FPS in every completed run on this sandbox workload. This is a CPU/software-Vulkan benchmark result and is not a claim about mobile GPU FPS.

Raw run output is stored in `perf-run-20261105/runs.log`; heartbeat and aggregate JSON are stored beside it in the delivered archive.
